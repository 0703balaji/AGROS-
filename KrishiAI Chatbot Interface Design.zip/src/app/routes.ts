import { createBrowserRouter } from "react-router";
import { Root } from "./Root";
import { LandingPage } from "./pages/LandingPage";
import { OnboardingPage } from "./pages/OnboardingPage";
import { EnhancedDashboardPage } from "./pages/EnhancedDashboardPage";
import { ChatPage } from "./pages/ChatPage";
import { ScanPage } from "./pages/ScanPage";
import { PestResultPage } from "./pages/PestResultPage";
import { InsightsPage } from "./pages/InsightsPage";
import { KnowledgePage } from "./pages/KnowledgePage";
import { ProfilePage } from "./pages/ProfilePage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: LandingPage },
      { path: "onboarding", Component: OnboardingPage },
      { path: "dashboard", Component: EnhancedDashboardPage },
      { path: "chat", Component: ChatPage },
      { path: "scan", Component: ScanPage },
      { path: "pest-results", Component: PestResultPage },
      { path: "insights", Component: InsightsPage },
      { path: "knowledge", Component: KnowledgePage },
      { path: "profile", Component: ProfilePage },
      // New feature routes (placeholder pages)
      { path: "community", Component: ProfilePage },
      { path: "marketplace", Component: ProfilePage },
      { path: "lifecycle", Component: ProfilePage },
      { path: "profit", Component: ProfilePage },
      { path: "mapping", Component: ProfilePage },
      { path: "organic", Component: ProfilePage },
      { path: "seeds", Component: ProfilePage },
      { path: "forum", Component: ProfilePage },
      { path: "dairy", Component: ProfilePage },
      { path: "aqua", Component: ProfilePage },
      { path: "mushroom", Component: ProfilePage },
      { path: "prices", Component: ProfilePage },
      { path: "fields", Component: ProfilePage },
      { path: "listings", Component: ProfilePage },
      { path: "transactions", Component: ProfilePage },
      { path: "analytics", Component: ProfilePage },
      { path: "achievements", Component: ProfilePage },
      { path: "saved", Component: ProfilePage },
      { path: "notifications", Component: ProfilePage },
      { path: "settings", Component: ProfilePage },
    ],
  },
]);