import { useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  CloudRain, Sun, Droplets, Bug, Leaf, TrendingUp, AlertTriangle, ChevronRight,
  Sparkles, Wind, ShoppingCart, Users, BookOpen, MapPin, Sprout, Target,
  Database, Truck, Award, Wifi, Heart, Zap, Factory, Fish, Milk,
  TreePine, Recycle, DollarSign, GraduationCap, MessageSquare, Camera,
  Share2, Package, Activity, Settings
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip, BarChart, Bar
} from "recharts";
import { MobileLayout } from "../components/MobileLayout";
import { MobileHeader } from "../components/MobileHeader";
import { PremiumCard } from "../components/PremiumCard";

const FARMER_IMG = "https://images.unsplash.com/photo-1608876537010-ac56d8731614?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxJbmRpYW4lMjBmYXJtZXIlMjBwb3J0cmFpdCUyMHZpbGxhZ2V8ZW58MXx8fHwxNzcyODEzMDgwfDA&ixlib=rb-4.1.0&q=80&w=1080";

const rainfallData = [
  { month: "Jan", mm: 18, id: "rain-jan" }, { month: "Feb", mm: 22, id: "rain-feb" }, { month: "Mar", mm: 35, id: "rain-mar" },
  { month: "Apr", mm: 60, id: "rain-apr" }, { month: "May", mm: 85, id: "rain-may" }, { month: "Jun", mm: 140, id: "rain-jun" },
];

const cropHealthData = [
  { crop: "Paddy", health: 88, id: "crop-paddy" }, { crop: "Wheat", health: 72, id: "crop-wheat" },
  { crop: "Cotton", health: 65, id: "crop-cotton" }, { crop: "Sugarcane", health: 91, id: "crop-sugarcane" },
];

const featureModules = [
  { icon: Users, title: "Farmer Community", desc: "Connect with 50K+ farmers", path: "/community", color: "#1565C0", gradient: "linear-gradient(135deg, #42A5F5 0%, #1565C0 100%)" },
  { icon: ShoppingCart, title: "Direct Marketplace", desc: "Sell directly to customers", path: "/marketplace", color: "#E65100", gradient: "linear-gradient(135deg, #FF8A65 0%, #E65100 100%)" },
  { icon: Sprout, title: "Crop Lifecycle", desc: "Seed to harvest tracking", path: "/lifecycle", color: "#2E7D32", gradient: "linear-gradient(135deg, #66BB6A 0%, #2E7D32 100%)" },
  { icon: Target, title: "Profit Insights", desc: "IFS profitability analysis", path: "/profit", color: "#7B1FA2", gradient: "linear-gradient(135deg, #BA68C8 0%, #7B1FA2 100%)" },
  { icon: MapPin, title: "Field Mapping", desc: "GPS-based field planning", path: "/mapping", color: "#0277BD", gradient: "linear-gradient(135deg, #4FC3F7 0%, #0277BD 100%)" },
  { icon: GraduationCap, title: "Learning Hub", desc: "Modern agri-tech courses", path: "/knowledge", color: "#C62828", gradient: "linear-gradient(135deg, #EF5350 0%, #C62828 100%)" },
  { icon: Bug, title: "Pest Management", desc: "AI-powered pest control", path: "/pest-results", color: "#D84315", gradient: "linear-gradient(135deg, #FF7043 0%, #D84315 100%)" },
  { icon: Camera, title: "Soil Scanner", desc: "Identify soil & suitability", path: "/scan", color: "#795548", gradient: "linear-gradient(135deg, #A1887F 0%, #795548 100%)" },
  { icon: Leaf, title: "Organic Farming", desc: "Traditional practices", path: "/organic", color: "#558B2F", gradient: "linear-gradient(135deg, #9CCC65 0%, #558B2F 100%)" },
  { icon: Package, title: "Seed Markets", desc: "Nearby seed availability", path: "/seeds", color: "#F57C00", gradient: "linear-gradient(135deg, #FFB74D 0%, #F57C00 100%)" },
  { icon: MessageSquare, title: "Experience Forum", desc: "Share farming stories", path: "/forum", color: "#0097A7", gradient: "linear-gradient(135deg, #4DD0E1 0%, #0097A7 100%)" },
  { icon: Sparkles, title: "AI Assistant", desc: "24/7 doubt clarification", path: "/chat", color: "#6A1B9A", gradient: "linear-gradient(135deg, #AB47BC 0%, #6A1B9A 100%)" },
  { icon: Milk, title: "Dairy Farming", desc: "Integrated dairy system", path: "/dairy", color: "#5D4037", gradient: "linear-gradient(135deg, #8D6E63 0%, #5D4037 100%)" },
  { icon: Fish, title: "Aquaculture", desc: "Fish farming insights", path: "/aqua", color: "#006064", gradient: "linear-gradient(135deg, #26C6DA 0%, #006064 100%)" },
  { icon: Factory, title: "Mushroom Farming", desc: "High-value cultivation", path: "/mushroom", color: "#4E342E", gradient: "linear-gradient(135deg, #A1887F 0%, #4E342E 100%)" },
  { icon: DollarSign, title: "Market Prices", desc: "Daily price intelligence", path: "/prices", color: "#1B5E20", gradient: "linear-gradient(135deg, #66BB6A 0%, #1B5E20 100%)" },
];

export function EnhancedDashboardPage() {
  const navigate = useNavigate();

  return (
    <MobileLayout>
      <MobileHeader />

      <div className="px-5 py-6" style={{ background: "#F8FAF9" }}>
        {/* Premium Welcome Banner */}
        <PremiumCard delay={0} className="mb-6 overflow-hidden relative" glass>
          <div className="p-6 pr-32 relative z-10">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={16} color="#FFC107" />
              <span style={{ color: "#2E7D32", fontSize: 11, fontWeight: 700, letterSpacing: "0.5px" }}>
                AI POWERED AGRITECH
              </span>
            </div>
            <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 22, color: "#1a1a1a", lineHeight: 1.3, marginBottom: 6 }}>
              Good Morning, Ravi! 🌱
            </h2>
            <p style={{ color: "#666", fontSize: 13, lineHeight: 1.5, marginBottom: 12 }}>
              Thanjavur District • Kharif Season • 3 Fields Active
            </p>
            <motion.button
              onClick={() => navigate("/chat")}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl"
              style={{
                background: "linear-gradient(135deg, #2E7D32 0%, #1B5E20 100%)",
                color: "#fff",
                fontSize: 13,
                fontWeight: 600,
                boxShadow: "0 4px 12px rgba(46, 125, 50, 0.25)",
              }}
            >
              <Sparkles size={14} />
              Ask AI Assistant
              <ChevronRight size={14} />
            </motion.button>
          </div>
          <div className="absolute right-0 bottom-0 top-0 flex items-end" style={{ width: 120 }}>
            <img
              src={FARMER_IMG}
              alt="Farmer"
              style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.4, objectPosition: "top", mixBlendMode: "multiply" }}
            />
          </div>
        </PremiumCard>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          {[
            { icon: Leaf, label: "Crop Health", value: "88%", color: "#2E7D32", bg: "#E8F5E9" },
            { icon: CloudRain, label: "Rainfall", value: "140mm", color: "#1565C0", bg: "#E3F2FD" },
            { icon: Bug, label: "Pest Risk", value: "High", color: "#C62828", bg: "#FFEBEE" },
          ].map((stat, idx) => (
            <PremiumCard key={stat.label} delay={0.1 + idx * 0.05} className="p-4 text-center">
              <div
                className="rounded-xl flex items-center justify-center mx-auto mb-2"
                style={{ width: 40, height: 40, background: stat.bg }}
              >
                <stat.icon size={20} color={stat.color} />
              </div>
              <p style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: 18, color: stat.color }}>
                {stat.value}
              </p>
              <p style={{ fontSize: 11, color: "#888", fontWeight: 500 }}>{stat.label}</p>
            </PremiumCard>
          ))}
        </div>

        {/* Weather Widget */}
        <PremiumCard delay={0.25} className="p-5 mb-6" gradient>
          <div className="flex items-center justify-between mb-4">
            <div>
              <p style={{ color: "#888", fontSize: 12, marginBottom: 4 }}>Thanjavur, Tamil Nadu</p>
              <div className="flex items-baseline gap-2">
                <span style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: 38, color: "#1a1a1a" }}>32°</span>
                <span style={{ color: "#666", fontSize: 14 }}>Partly Cloudy</span>
              </div>
            </div>
            <Sun size={56} color="#FFC107" style={{ opacity: 0.9 }} />
          </div>
          <div className="flex gap-5 pt-3 border-t" style={{ borderColor: "rgba(0, 0, 0, 0.06)" }}>
            {[
              { icon: Droplets, label: "Humidity", val: "74%" },
              { icon: Wind, label: "Wind", val: "12 km/h" },
              { icon: CloudRain, label: "Rain (7d)", val: "18mm" },
            ].map((w) => (
              <div key={w.label} className="flex items-center gap-2">
                <w.icon size={16} color="#666" />
                <div>
                  <p style={{ color: "#999", fontSize: 10 }}>{w.label}</p>
                  <p style={{ color: "#1a1a1a", fontSize: 13, fontWeight: 600 }}>{w.val}</p>
                </div>
              </div>
            ))}
          </div>
        </PremiumCard>

        {/* Pest Alert */}
        <PremiumCard delay={0.3} onClick={() => navigate("/pest-results")} className="p-5 mb-6">
          <div className="flex items-center gap-3 mb-4">
            <div
              className="rounded-xl flex items-center justify-center"
              style={{ width: 44, height: 44, background: "#FFEBEE" }}
            >
              <AlertTriangle size={22} color="#C62828" />
            </div>
            <div className="flex-1">
              <p style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 15, color: "#1a1a1a" }}>
                Active Pest Alerts
              </p>
              <p style={{ fontSize: 12, color: "#888" }}>3 threats detected in your area</p>
            </div>
            <ChevronRight size={20} color="#ccc" />
          </div>
          <div className="grid grid-cols-3 gap-2">
            {["Fall Armyworm", "Aphids", "Whitefly"].map((pest, idx) => (
              <div
                key={pest}
                className="rounded-xl p-2.5 text-center"
                style={{ background: idx === 0 ? "#FFEBEE" : "#FFF8E1" }}
              >
                <Bug size={16} color={idx === 0 ? "#C62828" : "#E65100"} className="mx-auto mb-1" />
                <p style={{ fontSize: 10, fontWeight: 600, color: "#333" }}>{pest}</p>
              </div>
            ))}
          </div>
        </PremiumCard>

        {/* Feature Modules Grid */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 17, color: "#1a1a1a" }}>
              Platform Features
            </h3>
            <Activity size={18} color="#2E7D32" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            {featureModules.map((feature, idx) => (
              <PremiumCard
                key={feature.title}
                delay={0.35 + idx * 0.03}
                onClick={() => navigate(feature.path)}
                className="p-4 relative overflow-hidden"
              >
                <div
                  className="absolute top-0 right-0 w-20 h-20 rounded-full"
                  style={{
                    background: feature.gradient,
                    opacity: 0.08,
                    transform: "translate(25%, -25%)",
                  }}
                />
                <div
                  className="rounded-xl flex items-center justify-center mb-3"
                  style={{ width: 44, height: 44, background: `${feature.color}15` }}
                >
                  <feature.icon size={22} color={feature.color} />
                </div>
                <p style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 13, color: "#1a1a1a", marginBottom: 4 }}>
                  {feature.title}
                </p>
                <p style={{ fontSize: 11, color: "#888", lineHeight: 1.4 }}>{feature.desc}</p>
              </PremiumCard>
            ))}
          </div>
        </div>

        {/* Charts Section */}
        <PremiumCard delay={0.5} className="p-5 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={18} color="#2E7D32" />
            <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 15, color: "#1a1a1a" }}>
              Crop Health Score
            </h3>
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={cropHealthData} barSize={28}>
              <XAxis dataKey="crop" tick={{ fontSize: 11, fill: "#888" }} axisLine={false} tickLine={false} />
              <YAxis hide domain={[0, 100]} />
              <Tooltip
                contentStyle={{ background: "#fff", border: "none", borderRadius: 12, boxShadow: "0 4px 16px rgba(0,0,0,0.1)", fontSize: 12 }}
                formatter={(val) => [`${val}%`, "Health"]}
              />
              <Bar dataKey="health" fill="url(#barGradient)" radius={[8, 8, 0, 0]} />
              <defs>
                <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#66BB6A" />
                  <stop offset="100%" stopColor="#2E7D32" />
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
        </PremiumCard>

        <PremiumCard delay={0.55} className="p-5 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <CloudRain size={18} color="#1565C0" />
            <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 15, color: "#1a1a1a" }}>
              Rainfall Forecast
            </h3>
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <AreaChart data={rainfallData}>
              <defs>
                <linearGradient id="rainGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1565C0" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#1565C0" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#888" }} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip
                contentStyle={{ background: "#fff", border: "none", borderRadius: 12, boxShadow: "0 4px 16px rgba(0,0,0,0.1)", fontSize: 12 }}
                formatter={(val) => [`${val}mm`, "Rainfall"]}
              />
              <Area type="monotone" dataKey="mm" stroke="#1565C0" strokeWidth={2.5} fill="url(#rainGradient)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </PremiumCard>

        {/* AI Recommendation Card */}
        <PremiumCard delay={0.6} onClick={() => navigate("/chat")} className="p-5 mb-4 overflow-hidden relative">
          <div
            className="absolute inset-0 opacity-5"
            style={{ background: "linear-gradient(135deg, #2E7D32 0%, #1B5E20 100%)" }}
          />
          <div className="relative z-10 flex items-start gap-3">
            <div className="rounded-xl p-2.5" style={{ background: "#E8F5E9" }}>
              <Sparkles size={20} color="#2E7D32" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Zap size={13} color="#FFC107" />
                <span style={{ color: "#2E7D32", fontSize: 11, fontWeight: 700, letterSpacing: "0.5px" }}>
                  AI RECOMMENDATION
                </span>
              </div>
              <p style={{ color: "#1a1a1a", fontSize: 14, fontWeight: 600, lineHeight: 1.6, marginBottom: 10 }}>
                Based on your soil and weather data, consider switching 20% of your paddy land to Black-eyed peas for better income this Rabi season.
              </p>
              <div className="flex items-center gap-2 text-sm" style={{ color: "#2E7D32", fontWeight: 600 }}>
                Learn more <ChevronRight size={16} />
              </div>
            </div>
          </div>
        </PremiumCard>
      </div>
    </MobileLayout>
  );
}
