import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { ChevronLeft, Search, BookOpen, Play, Star, Clock, ChevronRight, Leaf, Bug, Droplets, CloudRain, BarChart3, Users } from "lucide-react";
import { MobileLayout } from "../components/MobileLayout";

const CATEGORIES = [
  { label: "All", emoji: "📚" },
  { label: "Pests", emoji: "🐛" },
  { label: "Soil", emoji: "🌱" },
  { label: "Weather", emoji: "🌧" },
  { label: "Crops", emoji: "🌾" },
  { label: "Organic", emoji: "🍃" },
  { label: "Market", emoji: "📊" },
];

const ARTICLES = [
  {
    id: 1, title: "Complete Guide to Fall Armyworm Control", category: "Pests",
    emoji: "🐛", duration: "8 min read", rating: 4.9, reads: "12.4K",
    tags: ["Organic", "Paddy", "Tamil Nadu"],
    summary: "Learn to identify, treat, and prevent Fall Armyworm infestation using proven organic methods.",
    color: "#FFEBEE", border: "#EF9A9A",
  },
  {
    id: 2, title: "Soil Health: Building Organic Carbon", category: "Soil",
    emoji: "🌱", duration: "6 min read", rating: 4.8, reads: "9.1K",
    tags: ["Organic", "Soil Science", "Long-term"],
    summary: "Step-by-step guide to improving your soil's organic carbon content for better yields.",
    color: "#E8F5E9", border: "#A5D6A7",
  },
  {
    id: 3, title: "Kharif Season Crop Calendar for Tamil Nadu", category: "Crops",
    emoji: "🌾", duration: "10 min read", rating: 4.7, reads: "18.2K",
    tags: ["Kharif", "Tamil Nadu", "Planning"],
    summary: "Complete month-by-month farming calendar for Kharif season across Tamil Nadu districts.",
    color: "#E8F5E9", border: "#81C784",
  },
  {
    id: 4, title: "Neem-Based Pest Control: Complete Guide", category: "Organic",
    emoji: "🍃", duration: "7 min read", rating: 4.9, reads: "15.7K",
    tags: ["Organic", "DIY", "Eco-friendly"],
    summary: "How to prepare and apply neem oil, neem cake, and other neem-based solutions effectively.",
    color: "#F3E5F5", border: "#CE93D8",
  },
  {
    id: 5, title: "Rainwater Harvesting for Small Farms", category: "Weather",
    emoji: "🌧", duration: "5 min read", rating: 4.6, reads: "7.3K",
    tags: ["Water Management", "Climate Resilience"],
    summary: "Simple techniques to collect and store rainwater for irrigation during dry spells.",
    color: "#E3F2FD", border: "#90CAF9",
  },
  {
    id: 6, title: "Understanding MSP: Sell at the Right Price", category: "Market",
    emoji: "📊", duration: "4 min read", rating: 4.5, reads: "5.8K",
    tags: ["MSP", "Government Scheme", "Marketing"],
    summary: "How to access Minimum Support Price benefits and sell your crops for maximum profit.",
    color: "#FFF8E1", border: "#FFD54F",
  },
];

const VIDEOS = [
  { title: "Paddy Pest Detection using Mobile Camera", duration: "3:45", views: "34K", emoji: "📱" },
  { title: "Making Vermicompost at Home", duration: "7:12", views: "28K", emoji: "🐛" },
  { title: "Soil Testing Kit - How to Use", duration: "5:30", views: "19K", emoji: "🔬" },
  { title: "Weather-Smart Irrigation Techniques", duration: "6:15", views: "22K", emoji: "💧" },
];

const GOVT_SCHEMES = [
  { name: "PM-KISAN", desc: "₹6,000/year direct income support for farmers", status: "Apply Now", color: "#2E7D32" },
  { name: "Fasal Bima Yojana", desc: "Crop insurance at subsidized premium rates", status: "Enrolled", color: "#1565C0" },
  { name: "Soil Health Card", desc: "Free soil testing and fertilizer recommendations", status: "Get Card", color: "#795548" },
  { name: "KCC (Kisan Credit Card)", desc: "Easy credit up to ₹3 lakhs for farm needs", status: "Apply Now", color: "#E65100" },
];

export function KnowledgePage() {
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState<"articles" | "videos" | "schemes">("articles");

  const filteredArticles = ARTICLES.filter((a) => {
    const categoryMatch = activeCategory === "All" || a.category === activeCategory;
    const searchMatch = !searchQuery || a.title.toLowerCase().includes(searchQuery.toLowerCase());
    return categoryMatch && searchMatch;
  });

  return (
    <MobileLayout>
      {/* Header */}
      <div
        className="sticky top-0 z-40 px-4 py-3"
        style={{
          background: "linear-gradient(135deg, #1B5E20 0%, #2E7D32 100%)",
          boxShadow: "0 2px 20px rgba(27,94,32,0.3)",
        }}
      >
        <div className="flex items-center justify-between mb-3">
          <h1 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 18, color: "#fff" }}>
            Farmer Knowledge Hub
          </h1>
          <div className="rounded-full px-2 py-0.5" style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.2)" }}>
            <span style={{ color: "#fff", fontSize: 11, fontWeight: 600 }}>📚 {ARTICLES.length + VIDEOS.length} resources</span>
          </div>
        </div>

        {/* Search */}
        <div
          className="flex items-center gap-3 px-4 py-2.5 rounded-2xl"
          style={{ background: "rgba(255,255,255,0.15)", backdropFilter: "blur(10px)", border: "1px solid rgba(255,255,255,0.2)" }}
        >
          <Search size={16} color="rgba(255,255,255,0.7)" />
          <input
            placeholder="Search articles, guides, videos..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 bg-transparent outline-none"
            style={{ color: "#fff", fontSize: 13 }}
          />
        </div>
      </div>

      <div className="px-4 py-4">
        {/* Tabs */}
        <div className="flex rounded-xl p-1 mb-4" style={{ background: "#E8E8E8" }}>
          {[
            { key: "articles", label: "📖 Articles" },
            { key: "videos", label: "▶️ Videos" },
            { key: "schemes", label: "🏛️ Schemes" },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as typeof activeTab)}
              className="flex-1 py-2.5 rounded-lg"
              style={{
                background: activeTab === tab.key ? "#fff" : "transparent",
                color: activeTab === tab.key ? "#1B5E20" : "#666",
                fontWeight: activeTab === tab.key ? 700 : 400,
                fontSize: 12,
                boxShadow: activeTab === tab.key ? "0 2px 8px rgba(0,0,0,0.08)" : "none",
                transition: "all 0.2s ease",
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* ARTICLES */}
        {activeTab === "articles" && (
          <>
            {/* Categories */}
            <div className="flex gap-2 overflow-x-auto pb-1 mb-4" style={{ scrollbarWidth: "none" }}>
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.label}
                  onClick={() => setActiveCategory(cat.label)}
                  className="flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl"
                  style={{
                    background: activeCategory === cat.label ? "#1B5E20" : "#fff",
                    color: activeCategory === cat.label ? "#fff" : "#555",
                    fontWeight: activeCategory === cat.label ? 700 : 400,
                    fontSize: 12,
                    border: activeCategory === cat.label ? "none" : "1.5px solid #E0E0E0",
                    boxShadow: activeCategory === cat.label ? "0 4px 12px rgba(27,94,32,0.25)" : "none",
                    transition: "all 0.2s ease",
                  }}
                >
                  <span>{cat.emoji}</span>
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Featured Article */}
            {activeCategory === "All" && !searchQuery && (
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-2xl overflow-hidden mb-4"
                style={{ background: "linear-gradient(135deg, #1B5E20, #2E7D32)", boxShadow: "0 8px 24px rgba(27,94,32,0.3)" }}
              >
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <Star size={14} color="#FFC107" fill="#FFC107" />
                    <span style={{ color: "#FFC107", fontSize: 11, fontWeight: 600 }}>FEATURED GUIDE</span>
                  </div>
                  <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 18, color: "#fff", marginBottom: 8, lineHeight: 1.3 }}>
                    Complete Kharif Season Farming Guide for Tamil Nadu 2025
                  </h2>
                  <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 12, lineHeight: 1.5, marginBottom: 12 }}>
                    Comprehensive district-wise farming calendar, crop selection, pest management, and harvest tips.
                  </p>
                  <div className="flex items-center gap-4 mb-4">
                    <span style={{ color: "rgba(255,255,255,0.7)", fontSize: 11 }}><Clock size={11} style={{ display: "inline", marginRight: 3 }} />15 min read</span>
                    <span style={{ color: "rgba(255,255,255,0.7)", fontSize: 11 }}><Star size={11} style={{ display: "inline", marginRight: 3 }} />4.9/5</span>
                    <span style={{ color: "rgba(255,255,255,0.7)", fontSize: 11 }}><Users size={11} style={{ display: "inline", marginRight: 3 }} />48.2K reads</span>
                  </div>
                  <button
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl"
                    style={{ background: "rgba(255,255,255,0.2)", border: "1px solid rgba(255,255,255,0.3)", color: "#fff", fontSize: 13, fontWeight: 600 }}
                  >
                    <BookOpen size={15} /> Read Guide
                  </button>
                </div>
              </motion.div>
            )}

            {/* Article List */}
            {filteredArticles.map((article, i) => (
              <motion.div
                key={article.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
                className="rounded-2xl p-4 mb-3"
                style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)", border: `1px solid ${article.border}30` }}
              >
                <div className="flex items-start gap-3">
                  <div
                    className="rounded-2xl flex items-center justify-center flex-shrink-0"
                    style={{ width: 50, height: 50, background: article.color, fontSize: 24 }}
                  >
                    {article.emoji}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h3 style={{ fontWeight: 700, fontSize: 14, color: "#1a1a1a", lineHeight: 1.3 }}>{article.title}</h3>
                    </div>
                    <p style={{ fontSize: 12, color: "#666", lineHeight: 1.5, marginBottom: 8 }}>{article.summary}</p>
                    <div className="flex items-center gap-3 flex-wrap">
                      <span style={{ fontSize: 11, color: "#888" }}>
                        <Clock size={10} style={{ display: "inline", marginRight: 2 }} />{article.duration}
                      </span>
                      <span style={{ fontSize: 11, color: "#888" }}>
                        <Star size={10} style={{ display: "inline", marginRight: 2 }} fill="#FFC107" color="#FFC107" />{article.rating}
                      </span>
                      <span style={{ fontSize: 11, color: "#888" }}>{article.reads} reads</span>
                    </div>
                    <div className="flex gap-1 mt-2 flex-wrap">
                      {article.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-2 py-0.5 rounded-full"
                          style={{ background: article.color, color: "#555", fontSize: 10, fontWeight: 600 }}
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </>
        )}

        {/* VIDEOS */}
        {activeTab === "videos" && (
          <div>
            <div className="rounded-2xl overflow-hidden mb-4" style={{ background: "#000", position: "relative", height: 180 }}>
              <div className="absolute inset-0 flex items-center justify-center flex-col" style={{ background: "linear-gradient(135deg, #1B5E20, #2E7D32)", opacity: 0.9 }}>
                <div className="rounded-full flex items-center justify-center mb-3" style={{ width: 56, height: 56, background: "rgba(255,255,255,0.2)", border: "2px solid rgba(255,255,255,0.4)" }}>
                  <Play size={24} color="#fff" fill="#fff" />
                </div>
                <p style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 15, color: "#fff" }}>
                  KrishiAI Video Library
                </p>
                <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>Watch farming guides in your language</p>
              </div>
            </div>

            {VIDEOS.map((video, i) => (
              <motion.div
                key={video.title}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="rounded-2xl p-4 mb-3 flex items-center gap-4"
                style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
              >
                <div
                  className="rounded-2xl flex items-center justify-center relative flex-shrink-0"
                  style={{ width: 64, height: 64, background: "linear-gradient(135deg, #1B5E20, #2E7D32)", fontSize: 24 }}
                >
                  {video.emoji}
                  <div
                    className="absolute inset-0 flex items-center justify-center rounded-2xl"
                    style={{ background: "rgba(0,0,0,0.3)" }}
                  >
                    <Play size={20} color="#fff" fill="#fff" />
                  </div>
                </div>
                <div className="flex-1">
                  <p style={{ fontWeight: 700, fontSize: 13, color: "#1a1a1a", marginBottom: 4, lineHeight: 1.3 }}>{video.title}</p>
                  <div className="flex gap-3">
                    <span style={{ fontSize: 11, color: "#888" }}>⏱ {video.duration}</span>
                    <span style={{ fontSize: 11, color: "#888" }}>👁 {video.views} views</span>
                  </div>
                </div>
                <ChevronRight size={16} color="#888" />
              </motion.div>
            ))}
          </div>
        )}

        {/* SCHEMES */}
        {activeTab === "schemes" && (
          <div>
            <div
              className="rounded-2xl p-4 mb-4"
              style={{ background: "linear-gradient(135deg, #1B5E20, #2E7D32)", boxShadow: "0 8px 24px rgba(27,94,32,0.3)" }}
            >
              <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 16, color: "#fff", marginBottom: 6 }}>
                Government Schemes for Farmers
              </h3>
              <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 12 }}>
                Access all farmer welfare schemes in one place. Check eligibility and apply directly.
              </p>
            </div>

            {GOVT_SCHEMES.map((scheme, i) => (
              <motion.div
                key={scheme.name}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="rounded-2xl p-5 mb-3"
                style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="rounded-lg px-2 py-0.5" style={{ background: `${scheme.color}15` }}>
                        <span style={{ color: scheme.color, fontSize: 11, fontWeight: 700 }}>GOVT. SCHEME</span>
                      </div>
                    </div>
                    <h3 style={{ fontWeight: 700, fontSize: 16, color: "#1a1a1a" }}>{scheme.name}</h3>
                  </div>
                  <button
                    className="px-3 py-1.5 rounded-xl"
                    style={{
                      background: scheme.status === "Enrolled" ? "#E8F5E9" : `${scheme.color}`,
                      color: scheme.status === "Enrolled" ? "#2E7D32" : "#fff",
                      fontSize: 11,
                      fontWeight: 700,
                    }}
                  >
                    {scheme.status}
                  </button>
                </div>
                <p style={{ fontSize: 13, color: "#666", lineHeight: 1.5 }}>{scheme.desc}</p>
                <button className="flex items-center gap-1 mt-2" style={{ color: scheme.color, fontSize: 12, fontWeight: 600 }}>
                  Learn more <ChevronRight size={13} />
                </button>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </MobileLayout>
  );
}
