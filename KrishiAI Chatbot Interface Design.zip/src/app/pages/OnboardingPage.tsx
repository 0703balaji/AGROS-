import { useState } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Eye, EyeOff, MapPin, Leaf, CheckCircle2, ArrowRight, Phone } from "lucide-react";

const FIELD_IMG = "https://images.unsplash.com/photo-1716650205028-af3e1b453c3a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaWNlJTIwcGFkZHklMjBmaWVsZCUyMEluZGlhJTIwbGFuZHNjYXBlfGVufDF8fHx8MTc3MjgxMzA3N3ww&ixlib=rb-4.1.0&q=80&w=1080";

const SCREENS = ["welcome", "login", "register", "profile"];

export function OnboardingPage() {
  const navigate = useNavigate();
  const [screen, setScreen] = useState<typeof SCREENS[number]>("welcome");
  const [isLogin, setIsLogin] = useState(true);
  const [showPass, setShowPass] = useState(false);
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    name: "", phone: "", state: "Tamil Nadu", district: "Thanjavur", farmSize: "", crops: [] as string[],
  });

  const cropOptions = ["Rice / Paddy", "Wheat", "Cotton", "Sugarcane", "Vegetables", "Groundnut", "Maize", "Pulses"];

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden" style={{ background: "#F8FAF9" }}>
      {/* Background */}
      <div className="absolute inset-0">
        <img src={FIELD_IMG} alt="" className="w-full h-full object-cover" style={{ filter: "brightness(0.25) saturate(1.2)" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(27,94,32,0.7) 0%, rgba(0,0,0,0.8) 100%)" }} />
      </div>

      <div className="relative z-10 w-full max-w-md px-4 py-8">
        <AnimatePresence mode="wait">
          {screen === "welcome" && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -30 }}
              className="text-center"
            >
              {/* Logo */}
              <motion.div
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="inline-flex items-center justify-center rounded-3xl mb-6"
                style={{ width: 90, height: 90, background: "linear-gradient(135deg, #1B5E20, #2E7D32)", boxShadow: "0 20px 60px rgba(46,125,50,0.5)" }}
              >
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2C8 2 4 5 4 9c0 5 5 9 8 11 3-2 8-6 8-11 0-4-4-7-8-7z" fill="#A5D6A7" />
                  <circle cx="12" cy="9" r="2.5" fill="#fff" />
                  <path d="M9 14h6M10 17h4" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
                  <circle cx="8" cy="10" r="0.8" fill="#FFC107" />
                  <circle cx="16" cy="10" r="0.8" fill="#FFC107" />
                </svg>
              </motion.div>

              <h1 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: 32, color: "#fff", marginBottom: 8 }}>
                KrishiAI
              </h1>
              <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 16, marginBottom: 8 }}>
                Smart Farming Assistant
              </p>
              <p style={{ color: "rgba(255,255,255,0.55)", fontSize: 14, lineHeight: 1.7, marginBottom: 48 }}>
                AI-powered agricultural guidance for every farmer across India
              </p>

              {["2.4M+ Farmers Helped", "28 States Covered", "8 Languages Supported"].map((item) => (
                <div key={item} className="flex items-center gap-2 justify-center mb-2">
                  <CheckCircle2 size={16} color="#81C784" />
                  <span style={{ color: "rgba(255,255,255,0.8)", fontSize: 14 }}>{item}</span>
                </div>
              ))}

              <div className="flex flex-col gap-3 mt-10">
                <motion.button
                  whileTap={{ scale: 0.97 }}
                  onClick={() => setScreen("login")}
                  className="w-full py-4 rounded-2xl"
                  style={{
                    background: "linear-gradient(135deg, #2E7D32, #66BB6A)",
                    color: "#fff",
                    fontSize: 16,
                    fontWeight: 700,
                    boxShadow: "0 8px 30px rgba(46,125,50,0.4)",
                  }}
                >
                  Get Started
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.97 }}
                  onClick={() => navigate("/dashboard")}
                  className="w-full py-4 rounded-2xl"
                  style={{
                    background: "rgba(255,255,255,0.1)",
                    border: "1.5px solid rgba(255,255,255,0.25)",
                    color: "#fff",
                    fontSize: 15,
                    fontWeight: 600,
                  }}
                >
                  Continue as Guest
                </motion.button>
              </div>
            </motion.div>
          )}

          {screen === "login" && (
            <motion.div
              key="login"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
            >
              <button onClick={() => setScreen("welcome")} className="flex items-center gap-1 mb-6" style={{ color: "rgba(255,255,255,0.7)" }}>
                <ChevronLeft size={18} /> Back
              </button>

              <div
                className="rounded-3xl p-7"
                style={{ background: "rgba(255,255,255,0.95)", backdropFilter: "blur(20px)", boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}
              >
                {/* Tabs */}
                <div className="flex rounded-xl mb-6 p-1" style={{ background: "#F0F0F0" }}>
                  {["Login", "Register"].map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setIsLogin(tab === "Login")}
                      className="flex-1 py-2.5 rounded-lg transition-all"
                      style={{
                        background: (tab === "Login") === isLogin ? "#fff" : "transparent",
                        color: (tab === "Login") === isLogin ? "#1B5E20" : "#888",
                        fontWeight: (tab === "Login") === isLogin ? 700 : 500,
                        fontSize: 14,
                        boxShadow: (tab === "Login") === isLogin ? "0 2px 8px rgba(0,0,0,0.08)" : "none",
                      }}
                    >
                      {tab}
                    </button>
                  ))}
                </div>

                <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 22, color: "#1B5E20", marginBottom: 6 }}>
                  {isLogin ? "Welcome Back!" : "Join KrishiAI"}
                </h2>
                <p style={{ color: "#888", fontSize: 13, marginBottom: 24 }}>
                  {isLogin ? "Sign in to access your farming dashboard" : "Create your free farmer account"}
                </p>

                {!isLogin && (
                  <div className="mb-4">
                    <label style={{ fontSize: 13, fontWeight: 600, color: "#444", display: "block", marginBottom: 6 }}>Full Name</label>
                    <input
                      placeholder="Enter your name"
                      className="w-full px-4 py-3.5 rounded-xl outline-none"
                      style={{ background: "#F8F8F8", border: "1.5px solid #E0E0E0", fontSize: 14, color: "#333" }}
                    />
                  </div>
                )}

                <div className="mb-4">
                  <label style={{ fontSize: 13, fontWeight: 600, color: "#444", display: "block", marginBottom: 6 }}>
                    <Phone size={13} style={{ display: "inline", marginRight: 4 }} />
                    Phone Number
                  </label>
                  <div className="flex gap-2">
                    <div
                      className="flex items-center justify-center rounded-xl px-3"
                      style={{ background: "#F8F8F8", border: "1.5px solid #E0E0E0", fontSize: 14, color: "#333" }}
                    >
                      +91
                    </div>
                    <input
                      placeholder="9876543210"
                      className="flex-1 px-4 py-3.5 rounded-xl outline-none"
                      style={{ background: "#F8F8F8", border: "1.5px solid #E0E0E0", fontSize: 14, color: "#333" }}
                    />
                  </div>
                </div>

                <div className="mb-6">
                  <label style={{ fontSize: 13, fontWeight: 600, color: "#444", display: "block", marginBottom: 6 }}>Password</label>
                  <div className="relative">
                    <input
                      type={showPass ? "text" : "password"}
                      placeholder="Enter password"
                      className="w-full px-4 py-3.5 rounded-xl outline-none"
                      style={{ background: "#F8F8F8", border: "1.5px solid #E0E0E0", fontSize: 14, color: "#333" }}
                    />
                    <button
                      onClick={() => setShowPass(!showPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                    >
                      {showPass ? <EyeOff size={18} color="#888" /> : <Eye size={18} color="#888" />}
                    </button>
                  </div>
                </div>

                <motion.button
                  whileTap={{ scale: 0.97 }}
                  onClick={() => isLogin ? navigate("/dashboard") : setScreen("profile")}
                  className="w-full py-4 rounded-2xl flex items-center justify-center gap-2"
                  style={{
                    background: "linear-gradient(135deg, #1B5E20, #2E7D32)",
                    color: "#fff",
                    fontSize: 15,
                    fontWeight: 700,
                    boxShadow: "0 6px 20px rgba(46,125,50,0.35)",
                  }}
                >
                  {isLogin ? "Sign In" : "Continue"} <ArrowRight size={18} />
                </motion.button>

                <div className="mt-4 text-center">
                  <span style={{ fontSize: 13, color: "#888" }}>
                    {isLogin ? "Don't have an account? " : "Already have an account? "}
                  </span>
                  <button
                    onClick={() => setIsLogin(!isLogin)}
                    style={{ color: "#2E7D32", fontSize: 13, fontWeight: 600 }}
                  >
                    {isLogin ? "Register" : "Sign In"}
                  </button>
                </div>

                {/* Divider */}
                <div className="flex items-center gap-3 my-5">
                  <div style={{ flex: 1, height: 1, background: "#E0E0E0" }} />
                  <span style={{ color: "#888", fontSize: 12 }}>or continue with</span>
                  <div style={{ flex: 1, height: 1, background: "#E0E0E0" }} />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {["📱 OTP Login", "🌐 Google"].map((opt) => (
                    <button
                      key={opt}
                      className="py-3 rounded-xl"
                      style={{ border: "1.5px solid #E0E0E0", fontSize: 13, fontWeight: 500, color: "#444", background: "#fff" }}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {screen === "profile" && (
            <motion.div
              key="profile"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
            >
              <button onClick={() => setScreen("login")} className="flex items-center gap-1 mb-4" style={{ color: "rgba(255,255,255,0.7)" }}>
                <ChevronLeft size={18} /> Back
              </button>

              <div
                className="rounded-3xl p-7"
                style={{ background: "rgba(255,255,255,0.95)", backdropFilter: "blur(20px)", boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="rounded-2xl p-2" style={{ background: "#E8F5E9" }}>
                    <MapPin size={20} color="#2E7D32" />
                  </div>
                  <div>
                    <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 18, color: "#1B5E20" }}>Farm Profile</h2>
                    <p style={{ color: "#888", fontSize: 12 }}>Tell us about your farm</p>
                  </div>
                </div>

                <div className="mb-4">
                  <label style={{ fontSize: 13, fontWeight: 600, color: "#444", display: "block", marginBottom: 6 }}>State</label>
                  <select
                    className="w-full px-4 py-3.5 rounded-xl outline-none appearance-none"
                    style={{ background: "#F8F8F8", border: "1.5px solid #E0E0E0", fontSize: 14, color: "#333" }}
                    value={form.state}
                    onChange={(e) => setForm({ ...form, state: e.target.value })}
                  >
                    {["Tamil Nadu", "Maharashtra", "Punjab", "Uttar Pradesh", "Rajasthan", "Karnataka"].map((s) => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                </div>

                <div className="mb-4">
                  <label style={{ fontSize: 13, fontWeight: 600, color: "#444", display: "block", marginBottom: 6 }}>District</label>
                  <input
                    placeholder="Enter your district"
                    value={form.district}
                    onChange={(e) => setForm({ ...form, district: e.target.value })}
                    className="w-full px-4 py-3.5 rounded-xl outline-none"
                    style={{ background: "#F8F8F8", border: "1.5px solid #E0E0E0", fontSize: 14, color: "#333" }}
                  />
                </div>

                <div className="mb-5">
                  <label style={{ fontSize: 13, fontWeight: 600, color: "#444", display: "block", marginBottom: 6 }}>Farm Size (acres)</label>
                  <input
                    placeholder="e.g., 5 acres"
                    value={form.farmSize}
                    onChange={(e) => setForm({ ...form, farmSize: e.target.value })}
                    className="w-full px-4 py-3.5 rounded-xl outline-none"
                    style={{ background: "#F8F8F8", border: "1.5px solid #E0E0E0", fontSize: 14, color: "#333" }}
                  />
                </div>

                <div className="mb-6">
                  <label style={{ fontSize: 13, fontWeight: 600, color: "#444", display: "block", marginBottom: 8 }}>
                    <Leaf size={13} style={{ display: "inline", marginRight: 4 }} color="#2E7D32" />
                    Main Crops (select all that apply)
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {cropOptions.map((crop) => {
                      const selected = form.crops.includes(crop);
                      return (
                        <button
                          key={crop}
                          onClick={() => setForm({
                            ...form,
                            crops: selected ? form.crops.filter((c) => c !== crop) : [...form.crops, crop],
                          })}
                          className="px-3 py-2 rounded-xl"
                          style={{
                            background: selected ? "#E8F5E9" : "#F5F5F5",
                            border: `1.5px solid ${selected ? "#2E7D32" : "#E0E0E0"}`,
                            color: selected ? "#1B5E20" : "#555",
                            fontSize: 12,
                            fontWeight: selected ? 600 : 400,
                          }}
                        >
                          {selected && <CheckCircle2 size={12} style={{ display: "inline", marginRight: 4 }} />}
                          {crop}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <motion.button
                  whileTap={{ scale: 0.97 }}
                  onClick={() => navigate("/dashboard")}
                  className="w-full py-4 rounded-2xl flex items-center justify-center gap-2"
                  style={{
                    background: "linear-gradient(135deg, #1B5E20, #2E7D32)",
                    color: "#fff",
                    fontSize: 15,
                    fontWeight: 700,
                    boxShadow: "0 6px 20px rgba(46,125,50,0.35)",
                  }}
                >
                  Complete Setup <ArrowRight size={18} />
                </motion.button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
