import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  ChevronRight, Edit2, MapPin, Leaf, Award, Bell, Globe, Wifi,
  WifiOff, HelpCircle, LogOut, Shield, Star, TrendingUp, Sun, ChevronLeft
} from "lucide-react";
import { MobileLayout } from "../components/MobileLayout";

const FARMER_IMG = "https://images.unsplash.com/photo-1608876537010-ac56d8731614?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxJbmRpYW4lMjBmYXJtZXIlMjBwb3J0cmFpdCUyMHZpbGxhZ2V8ZW58MXx8fHwxNzcyODEzMDgwfDA&ixlib=rb-4.1.0&q=80&w=1080";

const ACHIEVEMENTS = [
  { emoji: "🌾", title: "First Harvest", desc: "Completed first AI-guided crop season", unlocked: true },
  { emoji: "🐛", title: "Pest Detective", desc: "Detected 5 pests using camera scanner", unlocked: true },
  { emoji: "🌱", title: "Soil Scientist", desc: "Improved soil health score by 20%", unlocked: false },
  { emoji: "📊", title: "Market Expert", desc: "Checked market prices 30 days in a row", unlocked: false },
];

const MENU_ITEMS = [
  {
    section: "Farm Profile",
    items: [
      { icon: MapPin, label: "Farm Location & District", sub: "Thanjavur, Tamil Nadu" },
      { icon: Leaf, label: "My Crops", sub: "Rice, Groundnut, Vegetables" },
      { icon: TrendingUp, label: "Crop History & Analytics", sub: "3 seasons recorded" },
    ],
  },
  {
    section: "Preferences",
    items: [
      { icon: Globe, label: "Language", sub: "English · Tamil available" },
      { icon: Bell, label: "Pest & Weather Alerts", sub: "Enabled · 3 alerts today" },
      { icon: Wifi, label: "Offline Mode", sub: "Download district data" },
    ],
  },
  {
    section: "Support",
    items: [
      { icon: HelpCircle, label: "Help Center", sub: "FAQs & tutorials" },
      { icon: Shield, label: "Privacy & Data", sub: "Manage your data" },
      { icon: Star, label: "Rate KrishiAI", sub: "Share your feedback" },
    ],
  },
];

export function ProfilePage() {
  const navigate = useNavigate();
  const [isOffline, setIsOffline] = useState(false);
  const [language, setLanguage] = useState("English");

  return (
    <MobileLayout>
      <div className="pb-4">
        {/* Header BG */}
        <div
          className="relative"
          style={{
            background: "linear-gradient(135deg, #1B5E20 0%, #2E7D32 60%, #388E3C 100%)",
            paddingBottom: 60,
          }}
        >
          <div className="flex items-center justify-between px-4 py-4">
            <h1 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 18, color: "#fff" }}>Profile</h1>
            <button className="p-2 rounded-xl" style={{ background: "rgba(255,255,255,0.15)" }}>
              <Edit2 size={18} color="#fff" />
            </button>
          </div>

          {/* Profile Card */}
          <div className="px-4 flex items-center gap-4">
            <div className="relative">
              <div
                className="rounded-3xl overflow-hidden"
                style={{ width: 72, height: 72, border: "3px solid rgba(255,255,255,0.5)", boxShadow: "0 8px 24px rgba(0,0,0,0.3)" }}
              >
                <img src={FARMER_IMG} alt="Farmer" className="w-full h-full object-cover object-top" />
              </div>
              <div
                className="absolute -bottom-1 -right-1 rounded-full border-2 border-white flex items-center justify-center"
                style={{ width: 22, height: 22, background: "#4CAF50" }}
              >
                <span style={{ fontSize: 9, color: "#fff" }}>✓</span>
              </div>
            </div>
            <div>
              <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 20, color: "#fff" }}>Ravi Kumar</h2>
              <div className="flex items-center gap-1.5 mb-1">
                <MapPin size={12} color="rgba(255,255,255,0.7)" />
                <span style={{ color: "rgba(255,255,255,0.8)", fontSize: 12 }}>Thanjavur, Tamil Nadu</span>
              </div>
              <div className="flex items-center gap-2">
                <div
                  className="flex items-center gap-1 px-2 py-0.5 rounded-full"
                  style={{ background: "rgba(255,255,255,0.2)", border: "1px solid rgba(255,255,255,0.3)" }}
                >
                  <Leaf size={11} color="#A5D6A7" />
                  <span style={{ color: "#A5D6A7", fontSize: 10, fontWeight: 600 }}>Organic Farmer</span>
                </div>
                <div
                  className="flex items-center gap-1 px-2 py-0.5 rounded-full"
                  style={{ background: "rgba(255,193,7,0.2)", border: "1px solid rgba(255,193,7,0.4)" }}
                >
                  <Star size={10} color="#FFC107" fill="#FFC107" />
                  <span style={{ color: "#FFC107", fontSize: 10, fontWeight: 600 }}>Pro Farmer</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Card */}
        <div className="px-4 -mt-10 relative z-10 mb-5">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl p-4 grid grid-cols-4 gap-2"
            style={{ background: "#fff", boxShadow: "0 8px 24px rgba(0,0,0,0.1)" }}
          >
            {[
              { label: "Chats", value: "147", icon: "💬" },
              { label: "Scans", value: "23", icon: "📷" },
              { label: "Farm (ac)", value: "8.5", icon: "🌾" },
              { label: "AI Score", value: "A+", icon: "⭐" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div style={{ fontSize: 20, marginBottom: 4 }}>{stat.icon}</div>
                <p style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: 16, color: "#1B5E20" }}>
                  {stat.value}
                </p>
                <p style={{ fontSize: 10, color: "#888" }}>{stat.label}</p>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Offline Mode Toggle */}
        <div className="px-4 mb-5">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="rounded-2xl p-4 flex items-center gap-3"
            style={{
              background: isOffline ? "#FFF8E1" : "#E8F5E9",
              border: `1.5px solid ${isOffline ? "#FFD54F" : "#A5D6A7"}`,
            }}
          >
            {isOffline ? (
              <WifiOff size={20} color="#E65100" />
            ) : (
              <Wifi size={20} color="#2E7D32" />
            )}
            <div className="flex-1">
              <p style={{ fontWeight: 700, fontSize: 14, color: isOffline ? "#E65100" : "#1B5E20" }}>
                {isOffline ? "Offline Mode Active" : "Online — All features available"}
              </p>
              <p style={{ fontSize: 11, color: "#888" }}>
                {isOffline ? "Using downloaded Thanjavur district data" : "Connected to KrishiAI servers"}
              </p>
            </div>
            <button
              onClick={() => setIsOffline(!isOffline)}
              className="rounded-full"
              style={{
                width: 44,
                height: 24,
                background: isOffline ? "#E0E0E0" : "#2E7D32",
                position: "relative",
                transition: "background 0.3s ease",
              }}
            >
              <motion.div
                className="absolute top-0.5 rounded-full"
                style={{ width: 20, height: 20, background: "#fff", boxShadow: "0 2px 4px rgba(0,0,0,0.2)" }}
                animate={{ left: isOffline ? 2 : 22 }}
                transition={{ duration: 0.25 }}
              />
            </button>
          </motion.div>
        </div>

        {/* Achievements */}
        <div className="px-4 mb-5">
          <div className="flex items-center justify-between mb-3">
            <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 15, color: "#1B5E20" }}>
              Achievements
            </h3>
            <span style={{ fontSize: 12, color: "#888" }}>2/4 earned</span>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2" style={{ scrollbarWidth: "none" }}>
            {ACHIEVEMENTS.map((ach, i) => (
              <motion.div
                key={ach.title}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.08 }}
                className="flex-shrink-0 flex flex-col items-center text-center p-3 rounded-2xl"
                style={{
                  width: 100,
                  background: ach.unlocked ? "#fff" : "#F5F5F5",
                  boxShadow: ach.unlocked ? "0 4px 16px rgba(0,0,0,0.08)" : "none",
                  border: ach.unlocked ? "1.5px solid #A5D6A7" : "1.5px solid #E0E0E0",
                  opacity: ach.unlocked ? 1 : 0.6,
                }}
              >
                <div style={{ fontSize: 30, filter: ach.unlocked ? "none" : "grayscale(1)", marginBottom: 6 }}>
                  {ach.emoji}
                </div>
                <p style={{ fontWeight: 700, fontSize: 11, color: ach.unlocked ? "#1B5E20" : "#999", marginBottom: 3 }}>
                  {ach.title}
                </p>
                <p style={{ fontSize: 9, color: "#888", lineHeight: 1.4 }}>{ach.desc}</p>
                {ach.unlocked && (
                  <div className="mt-2 px-2 py-0.5 rounded-full" style={{ background: "#E8F5E9" }}>
                    <span style={{ color: "#2E7D32", fontSize: 9, fontWeight: 700 }}>✓ EARNED</span>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>

        {/* Menu Sections */}
        {MENU_ITEMS.map((section, si) => (
          <div key={section.section} className="px-4 mb-5">
            <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 13, color: "#999", marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.05em" }}>
              {section.section}
            </h3>
            <div className="rounded-2xl overflow-hidden" style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}>
              {section.items.map((item, i) => (
                <motion.button
                  key={item.label}
                  whileTap={{ scale: 0.99 }}
                  className="w-full flex items-center gap-3 px-4 py-4"
                  style={{ borderBottom: i < section.items.length - 1 ? "1px solid #F5F5F5" : "none" }}
                >
                  <div className="rounded-xl p-2" style={{ background: "#E8F5E9" }}>
                    <item.icon size={18} color="#2E7D32" />
                  </div>
                  <div className="flex-1 text-left">
                    <p style={{ fontWeight: 600, fontSize: 14, color: "#1a1a1a" }}>{item.label}</p>
                    <p style={{ fontSize: 11, color: "#888", marginTop: 1 }}>{item.sub}</p>
                  </div>
                  <ChevronRight size={16} color="#bbb" />
                </motion.button>
              ))}
            </div>
          </div>
        ))}

        {/* Logout */}
        <div className="px-4 mb-4">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => navigate("/")}
            className="w-full py-4 rounded-2xl flex items-center justify-center gap-2"
            style={{
              background: "#fff",
              border: "1.5px solid #FFCDD2",
              color: "#C62828",
              fontSize: 14,
              fontWeight: 600,
            }}
          >
            <LogOut size={18} />
            Sign Out
          </motion.button>
        </div>

        <p style={{ textAlign: "center", color: "#bbb", fontSize: 11 }}>
          KrishiAI v2.1.0 · Made with 💚 for Indian Farmers
        </p>
      </div>
    </MobileLayout>
  );
}
