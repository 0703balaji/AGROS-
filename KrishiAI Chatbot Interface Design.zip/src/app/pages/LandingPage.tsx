import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  Leaf, Zap, Shield, Globe, ChevronRight, Star, ArrowRight,
  CheckCircle2, Sparkles, BarChart3, Camera, MessageCircle, CloudRain, Bug
} from "lucide-react";

const HERO_IMG = "https://images.unsplash.com/photo-1696371269777-88d1ce71642c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxJbmRpYW4lMjBmYXJtZXIlMjBncmVlbiUyMGZpZWxkJTIwY3JvcHN8ZW58MXx8fHwxNzcyODEzMDc2fDA&ixlib=rb-4.1.0&q=80&w=1080";
const TECH_IMG = "https://images.unsplash.com/photo-1677126577258-1a82fdf1a976?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZ3JpY3VsdHVyYWwlMjB0ZWNobm9sb2d5JTIwc21hcnQlMjBmYXJtaW5nJTIwZHJvbmV8ZW58MXx8fHwxNzcyODEzMDc2fDA&ixlib=rb-4.1.0&q=80&w=1080";

const features = [
  { icon: MessageCircle, title: "AI Chat Assistant", desc: "Get instant farming advice in your language", color: "#2E7D32" },
  { icon: Camera, title: "Crop Scanner", desc: "AI-powered pest & disease detection", color: "#795548" },
  { icon: CloudRain, title: "Weather Intelligence", desc: "Hyperlocal climate-resilient farming tips", color: "#1565C0" },
  { icon: BarChart3, title: "District Insights", desc: "Soil, crop & market data for your area", color: "#E65100" },
  { icon: Bug, title: "Pest Alerts", desc: "Real-time pest outbreak notifications", color: "#C62828" },
  { icon: Leaf, title: "Agroecology", desc: "Organic & sustainable farming guidance", color: "#558B2F" },
];

const stats = [
  { value: "2.4M+", label: "Farmers Helped" },
  { value: "28", label: "States Covered" },
  { value: "720+", label: "Districts" },
  { value: "8", label: "Languages" },
];

const testimonials = [
  { name: "Ravi Kumar", district: "Thanjavur, Tamil Nadu", text: "KrishiAI helped me identify the pest attacking my paddy crop and saved my entire harvest this season.", rating: 5, avatar: "RK" },
  { name: "Sunita Devi", district: "Varanasi, UP", text: "Ab mai apne khet ke liye AI se seedha salah le sakti hoon. Bahut faida hua!", rating: 5, avatar: "SD" },
  { name: "Gurpreet Singh", district: "Ludhiana, Punjab", text: "The crop recommendation system is amazing. My wheat yield improved by 30% this year.", rating: 5, avatar: "GS" },
];

const wordCycle = ["Smarter", "Sustainable", "Profitable", "Resilient", "Modern"];

export function LandingPage() {
  const navigate = useNavigate();
  const [wordIdx, setWordIdx] = useState(0);
  const [scrollY, setScrollY] = useState(0);
  const [isNavScrolled, setIsNavScrolled] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setWordIdx((i) => (i + 1) % wordCycle.length);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
      setIsNavScrolled(window.scrollY > 60);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Inter', sans-serif", overflowX: "hidden" }}>
      {/* Navbar */}
      <motion.nav
        className="fixed top-0 left-0 right-0 z-50 px-4 md:px-8"
        style={{
          background: isNavScrolled ? "rgba(255,255,255,0.95)" : "transparent",
          backdropFilter: isNavScrolled ? "blur(20px)" : "none",
          boxShadow: isNavScrolled ? "0 2px 20px rgba(0,0,0,0.08)" : "none",
          borderBottom: isNavScrolled ? "1px solid rgba(46,125,50,0.1)" : "none",
          transition: "all 0.3s ease",
          paddingTop: 14,
          paddingBottom: 14,
        }}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="flex items-center justify-center rounded-xl"
              style={{
                width: 40,
                height: 40,
                background: isNavScrolled ? "linear-gradient(135deg, #1B5E20, #2E7D32)" : "rgba(255,255,255,0.2)",
              }}
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M12 2C8 2 4 5 4 9c0 5 5 9 8 11 3-2 8-6 8-11 0-4-4-7-8-7z" fill="#A5D6A7" />
                <circle cx="12" cy="9" r="2" fill="#fff" />
                <path d="M9 14h6M10 17h4" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </div>
            <span
              style={{
                fontFamily: "'Poppins', sans-serif",
                fontWeight: 700,
                fontSize: 20,
                color: isNavScrolled ? "#1B5E20" : "#fff",
              }}
            >
              KrishiAI
            </span>
          </div>

          <div className="hidden md:flex items-center gap-6">
            {["Features", "How it Works", "Districts", "Testimonials"].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase().replace(" ", "-")}`}
                style={{ color: isNavScrolled ? "#333" : "rgba(255,255,255,0.85)", fontSize: 14, fontWeight: 500 }}
                className="hover:opacity-100 transition-opacity"
              >
                {item}
              </a>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/onboarding")}
              className="px-4 py-2 rounded-xl"
              style={{
                background: isNavScrolled ? "transparent" : "rgba(255,255,255,0.15)",
                border: `1.5px solid ${isNavScrolled ? "#2E7D32" : "rgba(255,255,255,0.4)"}`,
                color: isNavScrolled ? "#2E7D32" : "#fff",
                fontSize: 14,
                fontWeight: 600,
              }}
            >
              Sign In
            </button>
            <button
              onClick={() => navigate("/dashboard")}
              className="px-5 py-2 rounded-xl"
              style={{
                background: isNavScrolled ? "linear-gradient(135deg, #2E7D32, #66BB6A)" : "#fff",
                color: isNavScrolled ? "#fff" : "#1B5E20",
                fontSize: 14,
                fontWeight: 700,
                boxShadow: "0 4px 12px rgba(46,125,50,0.3)",
              }}
            >
              Get Started
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Hero */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* BG Image */}
        <div className="absolute inset-0">
          <img
            src={HERO_IMG}
            alt="Farmer field"
            className="w-full h-full object-cover"
            style={{ filter: "brightness(0.35)" }}
          />
          <div
            className="absolute inset-0"
            style={{
              background: "linear-gradient(135deg, rgba(27,94,32,0.85) 0%, rgba(46,125,50,0.6) 50%, rgba(0,0,0,0.4) 100%)",
            }}
          />
        </div>

        {/* Animated Particles */}
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: Math.random() * 6 + 3,
              height: Math.random() * 6 + 3,
              background: "rgba(165,214,167,0.5)",
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{ y: [-20, 20, -20], opacity: [0.3, 0.8, 0.3] }}
            transition={{ duration: 3 + Math.random() * 3, repeat: Infinity, delay: Math.random() * 2 }}
          />
        ))}

        <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-8 pt-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7 }}
              >
                <div
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6"
                  style={{ background: "rgba(165,214,167,0.2)", border: "1px solid rgba(165,214,167,0.4)" }}
                >
                  <Sparkles size={14} color="#A5D6A7" />
                  <span style={{ color: "#A5D6A7", fontSize: 12, fontWeight: 600 }}>Powered by Gemini AI</span>
                </div>

                <h1
                  style={{
                    fontFamily: "'Poppins', sans-serif",
                    fontWeight: 800,
                    fontSize: "clamp(32px, 5vw, 56px)",
                    color: "#fff",
                    lineHeight: 1.15,
                    marginBottom: 16,
                  }}
                >
                  AI-Powered Farming
                  <br />
                  Intelligence for
                  <br />
                  <span style={{ position: "relative", display: "inline-block" }}>
                    <AnimatePresence mode="wait">
                      <motion.span
                        key={wordIdx}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        style={{ color: "#A5D6A7", display: "inline-block" }}
                      >
                        {wordCycle[wordIdx]}
                      </motion.span>
                    </AnimatePresence>
                    {" "}India
                  </span>
                </h1>

                <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 17, lineHeight: 1.7, marginBottom: 36 }}>
                  Get personalized crop advice, pest detection, soil health insights, and climate-resilient farming guidance — in your local language, for your exact district.
                </p>

                <div className="flex flex-wrap gap-3">
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => navigate("/dashboard")}
                    className="flex items-center gap-2 px-7 py-3.5 rounded-2xl"
                    style={{
                      background: "linear-gradient(135deg, #2E7D32, #66BB6A)",
                      color: "#fff",
                      fontSize: 16,
                      fontWeight: 700,
                      boxShadow: "0 8px 30px rgba(46,125,50,0.45)",
                    }}
                  >
                    Get Started Free
                    <ArrowRight size={18} />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => navigate("/chat")}
                    className="flex items-center gap-2 px-7 py-3.5 rounded-2xl"
                    style={{
                      background: "rgba(255,255,255,0.12)",
                      border: "1.5px solid rgba(255,255,255,0.3)",
                      color: "#fff",
                      fontSize: 16,
                      fontWeight: 600,
                      backdropFilter: "blur(10px)",
                    }}
                  >
                    Try AI Chat
                    <MessageCircle size={18} />
                  </motion.button>
                </div>

                {/* Trust Badges */}
                <div className="flex flex-wrap gap-4 mt-8">
                  {["Free for farmers", "8 Languages", "Offline support"].map((badge) => (
                    <div key={badge} className="flex items-center gap-1.5">
                      <CheckCircle2 size={14} color="#81C784" />
                      <span style={{ color: "rgba(255,255,255,0.75)", fontSize: 13 }}>{badge}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>

            {/* Phone Mockup */}
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="hidden md:flex justify-center"
            >
              <div className="relative">
                <div
                  className="rounded-[40px] overflow-hidden"
                  style={{
                    width: 280,
                    height: 560,
                    background: "#111",
                    boxShadow: "0 30px 80px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.1)",
                    border: "8px solid #222",
                  }}
                >
                  <div style={{ background: "linear-gradient(135deg, #1B5E20, #2E7D32)", padding: "16px 14px 12px" }}>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-1.5">
                        <div className="rounded-lg" style={{ background: "rgba(255,255,255,0.15)", padding: "4px 6px" }}>
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                            <path d="M12 2C8 2 4 5 4 9c0 5 5 9 8 11 3-2 8-6 8-11 0-4-4-7-8-7z" fill="#A5D6A7" />
                          </svg>
                        </div>
                        <span style={{ fontFamily: "'Poppins', sans-serif", color: "#fff", fontSize: 13, fontWeight: 700 }}>KrishiAI</span>
                      </div>
                      <div className="flex gap-1">
                        <div className="rounded" style={{ background: "rgba(255,255,255,0.15)", padding: "3px 7px", fontSize: 9, color: "#fff" }}>Tamil Nadu</div>
                      </div>
                    </div>
                    <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 10 }}>Good morning, Ravi! 🌱</p>
                    <p style={{ color: "#fff", fontSize: 12, fontWeight: 600 }}>Your crops need attention today</p>
                  </div>

                  {/* Chat preview */}
                  <div style={{ background: "#F8FAF9", padding: 12, flex: 1 }}>
                    <div className="flex gap-2 mb-3">
                      <div className="rounded-full flex-shrink-0" style={{ width: 26, height: 26, background: "linear-gradient(135deg, #2E7D32, #66BB6A)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                          <path d="M12 2C8 2 4 5 4 9c0 5 5 9 8 11 3-2 8-6 8-11 0-4-4-7-8-7z" fill="#fff" />
                        </svg>
                      </div>
                      <div className="rounded-2xl rounded-tl-none p-2.5" style={{ background: "#fff", boxShadow: "0 2px 8px rgba(0,0,0,0.06)", maxWidth: "80%" }}>
                        <p style={{ fontSize: 10, color: "#333", lineHeight: 1.5 }}>Namaste! I detected a possible <strong>Fall Armyworm</strong> outbreak in Thanjavur district. Your paddy fields may be at risk. Shall I show you the treatment? 🌾</p>
                      </div>
                    </div>

                    <div className="flex gap-2 mb-3 justify-end">
                      <div className="rounded-2xl rounded-tr-none p-2.5" style={{ background: "linear-gradient(135deg, #2E7D32, #66BB6A)", maxWidth: "75%" }}>
                        <p style={{ fontSize: 10, color: "#fff", lineHeight: 1.5 }}>Yes, show me the solution please</p>
                      </div>
                    </div>

                    <div className="flex gap-2 mb-3">
                      <div className="rounded-full flex-shrink-0" style={{ width: 26, height: 26, background: "linear-gradient(135deg, #2E7D32, #66BB6A)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                          <path d="M12 2C8 2 4 5 4 9c0 5 5 9 8 11 3-2 8-6 8-11 0-4-4-7-8-7z" fill="#fff" />
                        </svg>
                      </div>
                      <div className="rounded-2xl rounded-tl-none p-2.5" style={{ background: "#fff", boxShadow: "0 2px 8px rgba(0,0,0,0.06)", maxWidth: "80%" }}>
                        <p style={{ fontSize: 10, color: "#333", lineHeight: 1.5 }}>✅ <strong>Organic Treatment:</strong><br />1. Neem oil spray (5ml/L)<br />2. Remove infected leaves<br />3. Apply Bt powder</p>
                      </div>
                    </div>

                    {/* Input bar */}
                    <div
                      className="flex items-center gap-2 px-2.5 py-1.5 rounded-2xl mt-2"
                      style={{ background: "#fff", border: "1.5px solid #E0E0E0", boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}
                    >
                      <span style={{ flex: 1, fontSize: 9, color: "#9E9E9E" }}>Ask about crops, pests...</span>
                      <div className="flex gap-1">
                        <div className="rounded-lg p-1" style={{ background: "#E8F5E9" }}>
                          <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="8" stroke="#2E7D32" strokeWidth="2"/></svg>
                        </div>
                        <div className="rounded-lg p-1" style={{ background: "#2E7D32" }}>
                          <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M5 12h14M12 5l7 7-7 7" stroke="#fff" strokeWidth="2" strokeLinecap="round"/></svg>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Floating cards */}
                <motion.div
                  animate={{ y: [-5, 5, -5] }}
                  transition={{ duration: 3, repeat: Infinity }}
                  className="absolute -left-16 top-20 rounded-xl p-3"
                  style={{ background: "rgba(255,255,255,0.95)", boxShadow: "0 8px 24px rgba(0,0,0,0.15)", width: 130 }}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Bug size={14} color="#C62828" />
                    <span style={{ fontSize: 10, color: "#C62828", fontWeight: 700 }}>Pest Alert</span>
                  </div>
                  <p style={{ fontSize: 9, color: "#333", lineHeight: 1.4 }}>Fall Armyworm detected in 3 districts</p>
                </motion.div>

                <motion.div
                  animate={{ y: [5, -5, 5] }}
                  transition={{ duration: 3.5, repeat: Infinity }}
                  className="absolute -right-14 bottom-24 rounded-xl p-3"
                  style={{ background: "rgba(255,255,255,0.95)", boxShadow: "0 8px 24px rgba(0,0,0,0.15)", width: 120 }}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Star size={13} color="#FFC107" fill="#FFC107" />
                    <span style={{ fontSize: 10, color: "#333", fontWeight: 700 }}>AI Score</span>
                  </div>
                  <p style={{ fontSize: 16, color: "#2E7D32", fontWeight: 800 }}>92%</p>
                  <p style={{ fontSize: 9, color: "#888" }}>Crop Health</p>
                </motion.div>
              </div>
            </motion.div>
          </div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.7 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16 pb-10"
          >
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="text-center p-4 rounded-2xl"
                style={{ background: "rgba(255,255,255,0.08)", backdropFilter: "blur(10px)", border: "1px solid rgba(255,255,255,0.15)" }}
              >
                <div style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: 28, color: "#fff" }}>{stat.value}</div>
                <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-4 md:px-8" style={{ background: "#F8FAF9" }}>
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-14">
            <div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4"
              style={{ background: "#E8F5E9", border: "1px solid #A5D6A7" }}
            >
              <Zap size={14} color="#2E7D32" />
              <span style={{ color: "#2E7D32", fontSize: 13, fontWeight: 600 }}>Platform Features</span>
            </div>
            <h2
              style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: "clamp(26px, 4vw, 40px)", color: "#1B5E20", marginBottom: 12 }}
            >
              Everything a Farmer Needs
            </h2>
            <p style={{ color: "#555", fontSize: 16, maxWidth: 560, margin: "0 auto" }}>
              From seed selection to harvest — KrishiAI provides intelligent, district-specific agricultural guidance at every step.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((feat, i) => (
              <motion.div
                key={feat.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                whileHover={{ y: -6, boxShadow: "0 16px 40px rgba(0,0,0,0.12)" }}
                className="p-6 rounded-2xl cursor-pointer"
                style={{ background: "#fff", boxShadow: "0 4px 20px rgba(0,0,0,0.06)", transition: "all 0.3s ease" }}
              >
                <div
                  className="flex items-center justify-center rounded-2xl mb-4"
                  style={{ width: 52, height: 52, background: `${feat.color}15` }}
                >
                  <feat.icon size={24} color={feat.color} />
                </div>
                <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 17, color: "#1a1a1a", marginBottom: 6 }}>
                  {feat.title}
                </h3>
                <p style={{ color: "#666", fontSize: 14, lineHeight: 1.6 }}>{feat.desc}</p>
                <div className="flex items-center gap-1.5 mt-4" style={{ color: feat.color, fontSize: 13, fontWeight: 600 }}>
                  Learn more <ChevronRight size={14} />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="py-20 px-4 md:px-8" style={{ background: "linear-gradient(135deg, #1B5E20 0%, #2E7D32 100%)" }}>
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-14">
            <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: "clamp(26px, 4vw, 40px)", color: "#fff", marginBottom: 12 }}>
              How KrishiAI Works
            </h2>
            <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 16 }}>Three simple steps to smarter farming</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: "01", title: "Select Your Location", desc: "Choose your state and district to get personalized, location-specific farming advice.", icon: Globe },
              { step: "02", title: "Chat or Scan", desc: "Ask questions in your language or capture crop photos for instant AI analysis.", icon: Camera },
              { step: "03", title: "Get Smart Advice", desc: "Receive actionable recommendations for crops, pests, soil, and market prices.", icon: Zap },
            ].map((item, i) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="text-center"
              >
                <div
                  className="inline-flex items-center justify-center rounded-3xl mb-5"
                  style={{ width: 72, height: 72, background: "rgba(255,255,255,0.15)", border: "2px solid rgba(255,255,255,0.3)" }}
                >
                  <item.icon size={30} color="#A5D6A7" />
                </div>
                <div style={{ fontFamily: "'Poppins', sans-serif", fontSize: 12, color: "#81C784", fontWeight: 700, marginBottom: 6 }}>STEP {item.step}</div>
                <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 20, color: "#fff", marginBottom: 10 }}>{item.title}</h3>
                <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 14, lineHeight: 1.7 }}>{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Smart Farming Image Section */}
      <section className="py-20 px-4 md:px-8" style={{ background: "#fff" }}>
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-5"
              style={{ background: "#E8F5E9", border: "1px solid #A5D6A7" }}
            >
              <Shield size={14} color="#2E7D32" />
              <span style={{ color: "#2E7D32", fontSize: 13, fontWeight: 600 }}>AI Technology</span>
            </div>
            <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: "clamp(24px, 3.5vw, 36px)", color: "#1B5E20", lineHeight: 1.3, marginBottom: 16 }}>
              Smart Farming Technology Built for Indian Agriculture
            </h2>
            <p style={{ color: "#555", fontSize: 15, lineHeight: 1.8, marginBottom: 20 }}>
              KrishiAI combines satellite data, local agricultural research, and advanced AI to give farmers the most accurate, district-specific advice possible.
            </p>
            {["District-level soil & weather data", "Multilingual voice & text input", "Real-time pest outbreak alerts", "Organic & agroecological guidance"].map((item) => (
              <div key={item} className="flex items-center gap-3 mb-3">
                <CheckCircle2 size={18} color="#2E7D32" />
                <span style={{ color: "#333", fontSize: 14 }}>{item}</span>
              </div>
            ))}
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => navigate("/dashboard")}
              className="flex items-center gap-2 px-7 py-3.5 rounded-2xl mt-6"
              style={{
                background: "linear-gradient(135deg, #2E7D32, #66BB6A)",
                color: "#fff",
                fontSize: 15,
                fontWeight: 700,
                boxShadow: "0 6px 24px rgba(46,125,50,0.35)",
              }}
            >
              Start Farming Smarter <ArrowRight size={18} />
            </motion.button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="rounded-3xl overflow-hidden" style={{ boxShadow: "0 20px 60px rgba(0,0,0,0.15)" }}>
              <img src={TECH_IMG} alt="Agri technology" className="w-full h-80 object-cover" />
            </div>
            <motion.div
              animate={{ y: [-5, 5, -5] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="absolute -bottom-6 -left-6 p-4 rounded-2xl"
              style={{ background: "#fff", boxShadow: "0 10px 30px rgba(0,0,0,0.12)" }}
            >
              <div style={{ fontSize: 10, color: "#888", marginBottom: 4 }}>Crop Yield Improvement</div>
              <div style={{ fontFamily: "'Poppins', sans-serif", fontSize: 24, fontWeight: 800, color: "#2E7D32" }}>+38%</div>
              <div style={{ fontSize: 10, color: "#888" }}>Average across districts</div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 px-4 md:px-8" style={{ background: "#F8FAF9" }}>
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-14">
            <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: "clamp(24px, 4vw, 38px)", color: "#1B5E20", marginBottom: 10 }}>
              Trusted by Farmers Across India
            </h2>
            <p style={{ color: "#555", fontSize: 15 }}>Real stories from real farmers</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <motion.div
                key={t.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12 }}
                className="p-6 rounded-2xl"
                style={{ background: "#fff", boxShadow: "0 4px 20px rgba(0,0,0,0.06)" }}
              >
                <div className="flex mb-3">
                  {[...Array(t.rating)].map((_, s) => (
                    <Star key={s} size={15} color="#FFC107" fill="#FFC107" />
                  ))}
                </div>
                <p style={{ color: "#444", fontSize: 14, lineHeight: 1.7, marginBottom: 16, fontStyle: "italic" }}>"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div
                    className="rounded-full flex items-center justify-center"
                    style={{ width: 40, height: 40, background: "linear-gradient(135deg, #2E7D32, #66BB6A)", color: "#fff", fontSize: 13, fontWeight: 700 }}
                  >
                    {t.avatar}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, color: "#1a1a1a", fontSize: 14 }}>{t.name}</div>
                    <div style={{ color: "#888", fontSize: 12 }}>{t.district}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 md:px-8" style={{ background: "linear-gradient(135deg, #1B5E20, #2E7D32)" }}>
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: "clamp(26px, 4vw, 42px)", color: "#fff", marginBottom: 16 }}>
              Start Your Smart Farming Journey Today
            </h2>
            <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 16, marginBottom: 36 }}>
              Join 2.4 million farmers who are farming smarter with KrishiAI
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <motion.button
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => navigate("/dashboard")}
                className="px-8 py-4 rounded-2xl"
                style={{
                  background: "#fff",
                  color: "#1B5E20",
                  fontSize: 16,
                  fontWeight: 700,
                  boxShadow: "0 8px 30px rgba(0,0,0,0.2)",
                }}
              >
                Launch App
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => navigate("/onboarding")}
                className="px-8 py-4 rounded-2xl"
                style={{
                  background: "rgba(255,255,255,0.15)",
                  border: "2px solid rgba(255,255,255,0.4)",
                  color: "#fff",
                  fontSize: 16,
                  fontWeight: 600,
                }}
              >
                Create Free Account
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 md:px-8" style={{ background: "#111" }}>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="rounded-xl flex items-center justify-center" style={{ width: 32, height: 32, background: "linear-gradient(135deg, #1B5E20, #2E7D32)" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <path d="M12 2C8 2 4 5 4 9c0 5 5 9 8 11 3-2 8-6 8-11 0-4-4-7-8-7z" fill="#A5D6A7" />
              </svg>
            </div>
            <span style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, color: "#fff", fontSize: 16 }}>KrishiAI</span>
          </div>
          <p style={{ color: "#666", fontSize: 13 }}>© 2026 KrishiAI — Empowering Indian Farmers with AI</p>
          <div className="flex gap-4">
            {["Privacy", "Terms", "Contact"].map((l) => (
              <a key={l} href="#" style={{ color: "#666", fontSize: 13 }}>{l}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
