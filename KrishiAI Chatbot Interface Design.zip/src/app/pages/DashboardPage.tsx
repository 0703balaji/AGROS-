import { useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  CloudRain, Sun, Droplets, Bug, Leaf, TrendingUp,
  AlertTriangle, ChevronRight, Sparkles, Wind, ShoppingCart
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip, BarChart, Bar
} from "recharts";
import { MobileLayout } from "../components/MobileLayout";
import { MobileHeader } from "../components/MobileHeader";

const FARMER_IMG = "https://images.unsplash.com/photo-1608876537010-ac56d8731614?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxJbmRpYW4lMjBmYXJtZXIlMjBwb3J0cmFpdCUyMHZpbGxhZ2V8ZW58MXx8fHwxNzcyODEzMDgwfDA&ixlib=rb-4.1.0&q=80&w=1080";

const rainfallData = [
  { month: "Jan", mm: 18, id: "rain-jan" }, { month: "Feb", mm: 22, id: "rain-feb" }, { month: "Mar", mm: 35, id: "rain-mar" },
  { month: "Apr", mm: 60, id: "rain-apr" }, { month: "May", mm: 85, id: "rain-may" }, { month: "Jun", mm: 140, id: "rain-jun" },
  { month: "Jul", mm: 190, id: "rain-jul" }, { month: "Aug", mm: 178, id: "rain-aug" }, { month: "Sep", mm: 120, id: "rain-sep" },
];

const cropHealthData = [
  { crop: "Paddy", health: 88, id: "crop-paddy" }, { crop: "Wheat", health: 72, id: "crop-wheat" }, { crop: "Cotton", health: 65, id: "crop-cotton" },
  { crop: "Sugarcane", health: 91, id: "crop-sugarcane" }, { crop: "Vegetables", health: 78, id: "crop-veg" },
];

const pestAlerts = [
  { pest: "Fall Armyworm", crop: "Paddy", severity: "High", districts: 3, color: "#C62828", bg: "#FFEBEE" },
  { pest: "Aphids", crop: "Cotton", severity: "Medium", districts: 1, color: "#E65100", bg: "#FFF3E0" },
  { pest: "Whitefly", crop: "Tomato", severity: "Low", districts: 2, color: "#1565C0", bg: "#E3F2FD" },
];

const quickActions = [
  { emoji: "🌾", title: "Best crops\nfor my district", path: "/insights", color: "#E8F5E9", border: "#A5D6A7" },
  { emoji: "🐛", title: "Identify pest\nfrom photo", path: "/scan", color: "#FFF3E0", border: "#FFCC02" },
  { emoji: "🌱", title: "Organic fertilizer\nguide", path: "/chat", color: "#F3E5F5", border: "#CE93D8" },
  { emoji: "🌧", title: "Weather\nadvice", path: "/insights", color: "#E3F2FD", border: "#90CAF9" },
  { emoji: "📊", title: "Soil improvement\ntips", path: "/knowledge", color: "#FBE9E7", border: "#FFAB91" },
];

const marketPrices = [
  { crop: "Rice (per quintal)", price: "₹2,183", change: "+2.3%", up: true },
  { crop: "Wheat (per quintal)", price: "₹2,275", change: "+0.8%", up: true },
  { crop: "Cotton (per quintal)", price: "₹6,620", change: "-1.2%", up: false },
  { crop: "Groundnut (per quintal)", price: "₹5,440", change: "+3.1%", up: true },
];

export function DashboardPage() {
  const navigate = useNavigate();

  return (
    <MobileLayout>
      <MobileHeader />

      <div className="px-4 py-4">
        {/* Welcome Banner */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl overflow-hidden mb-5 relative"
          style={{ background: "linear-gradient(135deg, #1B5E20 0%, #2E7D32 60%, #388E3C 100%)", boxShadow: "0 8px 24px rgba(27,94,32,0.3)" }}
        >
          <div className="p-5 pr-28 relative z-10">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={14} color="#FFC107" />
              <span style={{ color: "#FFC107", fontSize: 11, fontWeight: 600 }}>AI POWERED</span>
            </div>
            <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 18, color: "#fff", lineHeight: 1.3, marginBottom: 4 }}>
              Good Morning, Ravi! 🌱
            </h2>
            <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 12, lineHeight: 1.5 }}>
              Thanjavur District • Kharif Season
            </p>
            <button
              onClick={() => navigate("/chat")}
              className="mt-3 flex items-center gap-1.5 px-4 py-2 rounded-xl"
              style={{ background: "rgba(255,255,255,0.18)", border: "1px solid rgba(255,255,255,0.25)", color: "#fff", fontSize: 12, fontWeight: 600 }}
            >
              Ask AI <ChevronRight size={13} />
            </button>
          </div>
          <div className="absolute right-0 bottom-0 top-0 flex items-end" style={{ width: 110 }}>
            <img
              src={FARMER_IMG}
              alt="Farmer"
              style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.5, objectPosition: "top" }}
            />
          </div>
        </motion.div>

        {/* Weather Strip */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="rounded-2xl p-4 mb-5"
          style={{ background: "linear-gradient(135deg, #1565C0, #1976D2)", boxShadow: "0 6px 20px rgba(21,101,192,0.25)" }}
        >
          <div className="flex items-center justify-between mb-3">
            <div>
              <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 11, marginBottom: 2 }}>Thanjavur, Tamil Nadu</p>
              <div className="flex items-end gap-2">
                <span style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 36, color: "#fff" }}>32°</span>
                <span style={{ color: "rgba(255,255,255,0.8)", fontSize: 14, marginBottom: 6 }}>Partly Cloudy</span>
              </div>
            </div>
            <Sun size={44} color="#FFC107" />
          </div>
          <div className="flex gap-4">
            {[
              { icon: Droplets, label: "Humidity", val: "74%" },
              { icon: Wind, label: "Wind", val: "12 km/h" },
              { icon: CloudRain, label: "Rain (7d)", val: "18mm" },
            ].map((w) => (
              <div key={w.label} className="flex items-center gap-1.5">
                <w.icon size={13} color="rgba(255,255,255,0.7)" />
                <div>
                  <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 9 }}>{w.label}</p>
                  <p style={{ color: "#fff", fontSize: 11, fontWeight: 600 }}>{w.val}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Pest Alert */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="rounded-2xl p-4 mb-5"
          style={{ background: "#FFF8E1", border: "1.5px solid #FFD54F", boxShadow: "0 4px 16px rgba(255,193,7,0.15)" }}
        >
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle size={16} color="#F57F17" />
            <span style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 14, color: "#E65100" }}>Active Pest Alerts</span>
            <span className="ml-auto rounded-full px-2 py-0.5" style={{ background: "#FF6F00", color: "#fff", fontSize: 10, fontWeight: 700 }}>
              {pestAlerts.length} Active
            </span>
          </div>
          {pestAlerts.map((alert) => (
            <motion.div
              key={alert.pest}
              whileTap={{ scale: 0.98 }}
              onClick={() => navigate("/pest-results")}
              className="flex items-center gap-3 p-3 rounded-xl mb-2 cursor-pointer"
              style={{ background: alert.bg }}
            >
              <Bug size={18} color={alert.color} />
              <div className="flex-1">
                <p style={{ fontWeight: 600, fontSize: 13, color: "#1a1a1a" }}>{alert.pest}</p>
                <p style={{ fontSize: 11, color: "#666" }}>Affects {alert.crop} · {alert.districts} districts</p>
              </div>
              <span
                className="px-2 py-0.5 rounded-full"
                style={{ background: alert.color, color: "#fff", fontSize: 10, fontWeight: 700 }}
              >
                {alert.severity}
              </span>
            </motion.div>
          ))}
        </motion.div>

        {/* Quick Action Cards (swipeable) */}
        <div className="mb-5">
          <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 15, color: "#1B5E20", marginBottom: 12 }}>
            Quick Assistance
          </h3>
          <div className="flex gap-3 overflow-x-auto pb-2" style={{ scrollbarWidth: "none" }}>
            {quickActions.map((action) => (
              <motion.button
                key={action.title}
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate(action.path)}
                className="flex-shrink-0 flex flex-col items-center justify-center rounded-2xl p-4 text-center"
                style={{
                  width: 105,
                  minHeight: 100,
                  background: action.color,
                  border: `1.5px solid ${action.border}`,
                  boxShadow: "0 4px 12px rgba(0,0,0,0.06)",
                }}
              >
                <span style={{ fontSize: 28, marginBottom: 6 }}>{action.emoji}</span>
                <span style={{ fontSize: 11, color: "#333", fontWeight: 600, lineHeight: 1.4, whiteSpace: "pre-line" }}>
                  {action.title}
                </span>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Crop Health Chart */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="rounded-2xl p-4 mb-5"
          style={{ background: "#fff", boxShadow: "0 4px 20px rgba(0,0,0,0.07)" }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Leaf size={16} color="#2E7D32" />
            <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 14, color: "#1B5E20" }}>
              Crop Health Score
            </h3>
            <button onClick={() => navigate("/insights")} className="ml-auto flex items-center gap-1" style={{ color: "#2E7D32", fontSize: 12, fontWeight: 600 }}>
              View All <ChevronRight size={13} />
            </button>
          </div>
          <ResponsiveContainer width="100%" height={150}>
            <BarChart data={cropHealthData} barSize={24}>
              <XAxis dataKey="crop" tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} />
              <YAxis hide domain={[0, 100]} />
              <Tooltip
                contentStyle={{ background: "#fff", border: "none", borderRadius: 12, boxShadow: "0 4px 16px rgba(0,0,0,0.1)", fontSize: 12 }}
                formatter={(val) => [`${val}%`, "Health"]}
              />
              <Bar dataKey="health" fill="#2E7D32" radius={[6, 6, 0, 0]}
                label={{ position: "top", fontSize: 10, fill: "#2E7D32", fontWeight: 600 }}
              />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Rainfall Chart */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="rounded-2xl p-4 mb-5"
          style={{ background: "#fff", boxShadow: "0 4px 20px rgba(0,0,0,0.07)" }}
        >
          <div className="flex items-center gap-2 mb-4">
            <CloudRain size={16} color="#1565C0" />
            <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 14, color: "#1a1a1a" }}>
              Rainfall Prediction (mm)
            </h3>
          </div>
          <ResponsiveContainer width="100%" height={130}>
            <AreaChart data={rainfallData}>
              <defs>
                <linearGradient id="rainGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1565C0" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#1565C0" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip
                contentStyle={{ background: "#fff", border: "none", borderRadius: 12, boxShadow: "0 4px 16px rgba(0,0,0,0.1)", fontSize: 12 }}
                formatter={(val) => [`${val}mm`, "Rainfall"]}
              />
              <Area type="monotone" dataKey="mm" stroke="#1565C0" strokeWidth={2} fill="url(#rainGrad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Market Prices */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="rounded-2xl p-4 mb-5"
          style={{ background: "#fff", boxShadow: "0 4px 20px rgba(0,0,0,0.07)" }}
        >
          <div className="flex items-center gap-2 mb-4">
            <ShoppingCart size={16} color="#795548" />
            <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 14, color: "#1a1a1a" }}>
              Mandi Prices Today
            </h3>
            <span className="ml-auto text-xs px-2 py-0.5 rounded-full" style={{ background: "#E8F5E9", color: "#2E7D32", fontWeight: 600 }}>Live</span>
          </div>
          {marketPrices.map((item) => (
            <div key={item.crop} className="flex items-center justify-between py-2.5" style={{ borderBottom: "1px solid #F5F5F5" }}>
              <span style={{ fontSize: 13, color: "#333" }}>{item.crop}</span>
              <div className="flex items-center gap-2">
                <span style={{ fontWeight: 700, fontSize: 13, color: "#1a1a1a" }}>{item.price}</span>
                <span style={{ fontSize: 11, fontWeight: 600, color: item.up ? "#2E7D32" : "#C62828" }}>
                  {item.up ? "↑" : "↓"} {item.change}
                </span>
              </div>
            </div>
          ))}
        </motion.div>

        {/* AI Insight Card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate("/chat")}
          className="rounded-2xl p-5 mb-4 cursor-pointer"
          style={{
            background: "linear-gradient(135deg, #1B5E20, #2E7D32)",
            boxShadow: "0 8px 24px rgba(27,94,32,0.3)",
          }}
        >
          <div className="flex items-start gap-3">
            <div className="rounded-xl p-2" style={{ background: "rgba(255,255,255,0.2)" }}>
              <TrendingUp size={20} color="#fff" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Sparkles size={13} color="#FFC107" />
                <span style={{ color: "#FFC107", fontSize: 11, fontWeight: 600 }}>AI RECOMMENDATION</span>
              </div>
              <p style={{ color: "#fff", fontSize: 14, fontWeight: 600, lineHeight: 1.5, marginBottom: 8 }}>
                Based on your soil and weather data, consider switching 20% of your paddy land to Black-eyed peas for better income this Rabi season.
              </p>
              <button className="flex items-center gap-1" style={{ color: "#A5D6A7", fontSize: 13, fontWeight: 600 }}>
                Chat with AI about this <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </MobileLayout>
  );
}