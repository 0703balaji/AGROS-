import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  ChevronLeft, AlertTriangle, CheckCircle2, ChevronRight, Share2,
  BookOpen, MessageCircle, Bug, Leaf, Info, Download
} from "lucide-react";

const LEAF_IMG = "https://images.unsplash.com/photo-1694100223107-c898e5c117c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbGFudCUyMGxlYWYlMjBkaXNlYXNlJTIwcGVzdCUyMGNsb3NldXB8ZW58MXx8fHwxNzcyODEzMDc5fDA&ixlib=rb-4.1.0&q=80&w=1080";

const SOIL_IMG = "https://images.unsplash.com/photo-1737960320564-9e681df95dc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2lsJTIwaGVhbHRoJTIwb3JnYW5pYyUyMGZhcm1pbmclMjBoYW5kc3xlbnwxfHx8fDE3NzI4MTMwNzl8MA&ixlib=rb-4.1.0&q=80&w=1080";

const pestData = {
  name: "Fall Armyworm",
  scientific: "Spodoptera frugiperda",
  confidence: 92,
  severity: "High",
  affectedCrop: "Paddy (Rice)",
  stage: "Early infestation",
  affectedArea: "~15% of visible leaf area",
  symptoms: [
    "Ragged, irregular holes in leaves",
    "Frass (excrement) visible on leaves",
    "Young larvae visible in leaf funnels",
    "Yellowing of leaf tips",
  ],
  organicTreatments: [
    {
      title: "Neem Oil Spray",
      desc: "Mix 5ml neem oil + 1ml liquid soap per 1L water. Spray on leaves at dawn or dusk.",
      effectiveness: 78,
      icon: "🌿",
    },
    {
      title: "Bt (Bacillus thuringiensis)",
      desc: "Apply 1g Bt powder per liter of water. Effective against larval stage.",
      effectiveness: 85,
      icon: "🦠",
    },
    {
      title: "Remove Infested Leaves",
      desc: "Manually remove and destroy heavily infested leaves to prevent spread.",
      effectiveness: 65,
      icon: "✂️",
    },
    {
      title: "Pheromone Traps",
      desc: "Set 5-8 FAW pheromone traps per acre for population monitoring and control.",
      effectiveness: 72,
      icon: "🪤",
    },
  ],
  prevention: [
    "Use pest-resistant paddy varieties (TRY3, ADT45)",
    "Maintain field hygiene, remove crop residues",
    "Practice crop rotation with legumes",
    "Install bird perches (10/acre) to attract natural predators",
    "Intercrop with marigold or coriander",
  ],
  nearbyDistricts: [
    { name: "Thanjavur", risk: "High", color: "#C62828" },
    { name: "Tiruvarur", risk: "Medium", color: "#E65100" },
    { name: "Nagapattinam", risk: "Low", color: "#2E7D32" },
  ],
};

export function PestResultPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"organic" | "prevention" | "districts">("organic");

  const confidenceColor =
    pestData.confidence >= 85 ? "#C62828" : pestData.confidence >= 70 ? "#E65100" : "#2E7D32";

  return (
    <div className="min-h-screen" style={{ background: "#F8FAF9", fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div
        className="sticky top-0 z-40 flex items-center gap-3 px-4 py-3"
        style={{ background: "rgba(255,255,255,0.96)", backdropFilter: "blur(20px)", borderBottom: "1px solid rgba(0,0,0,0.06)", boxShadow: "0 2px 12px rgba(0,0,0,0.05)" }}
      >
        <button onClick={() => navigate("/scan")} className="rounded-xl p-2" style={{ background: "#F5F5F5" }}>
          <ChevronLeft size={20} color="#333" />
        </button>
        <h1 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 16, color: "#1B5E20", flex: 1 }}>
          AI Diagnosis Result
        </h1>
        <button className="rounded-xl p-2" style={{ background: "#F5F5F5" }}>
          <Share2 size={18} color="#555" />
        </button>
        <button className="rounded-xl p-2" style={{ background: "#F5F5F5" }}>
          <Download size={18} color="#555" />
        </button>
      </div>

      <div className="pb-6">
        {/* Crop Image */}
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative"
          style={{ height: 230 }}
        >
          <img
            src={LEAF_IMG}
            alt="Analyzed crop"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, transparent 50%, rgba(0,0,0,0.6))" }} />

          {/* Confidence badge */}
          <div className="absolute top-4 right-4">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.3, type: "spring" }}
              className="px-3 py-2 rounded-2xl"
              style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(10px)" }}
            >
              <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 10 }}>AI Confidence</p>
              <p style={{ color: "#FFC107", fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: 22 }}>{pestData.confidence}%</p>
            </motion.div>
          </div>

          {/* Bottom info */}
          <div className="absolute bottom-0 left-0 right-0 px-5 pb-4">
            <div className="flex items-center gap-2 mb-1">
              <AlertTriangle size={14} color="#FFC107" />
              <span style={{ color: "#FFC107", fontSize: 12, fontWeight: 600 }}>PEST DETECTED</span>
            </div>
            <p style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 20, color: "#fff" }}>
              {pestData.name}
            </p>
            <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 12, fontStyle: "italic" }}>{pestData.scientific}</p>
          </div>
        </motion.div>

        {/* Quick Stats */}
        <div className="px-4 -mt-3 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="rounded-2xl p-4 grid grid-cols-3 gap-3"
            style={{ background: "#fff", boxShadow: "0 8px 24px rgba(0,0,0,0.1)" }}
          >
            {[
              { label: "Severity", value: pestData.severity, color: "#C62828", bg: "#FFEBEE" },
              { label: "Crop", value: "Paddy", color: "#1B5E20", bg: "#E8F5E9" },
              { label: "Stage", value: "Early", color: "#E65100", bg: "#FFF3E0" },
            ].map((stat) => (
              <div
                key={stat.label}
                className="text-center rounded-xl py-2.5"
                style={{ background: stat.bg }}
              >
                <p style={{ fontWeight: 700, fontSize: 13, color: stat.color }}>{stat.value}</p>
                <p style={{ fontSize: 10, color: "#888", marginTop: 2 }}>{stat.label}</p>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Diagnosis Card */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mx-4 mt-4 rounded-2xl p-4"
          style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
        >
          <div className="flex items-center gap-2 mb-3">
            <Bug size={16} color="#C62828" />
            <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 15, color: "#1a1a1a" }}>
              AI Diagnosis
            </h2>
          </div>

          <div className="mb-3">
            <p style={{ fontSize: 12, color: "#888", marginBottom: 6 }}>AI Confidence</p>
            <div className="flex items-center gap-3">
              <div className="flex-1 rounded-full overflow-hidden" style={{ height: 8, background: "#F0F0F0" }}>
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${pestData.confidence}%` }}
                  transition={{ delay: 0.5, duration: 0.8, ease: "easeOut" }}
                  className="h-full rounded-full"
                  style={{ background: `linear-gradient(90deg, ${confidenceColor}, #FF5252)` }}
                />
              </div>
              <span style={{ fontWeight: 700, fontSize: 15, color: confidenceColor }}>{pestData.confidence}%</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-sm">
            {[
              { key: "Affected Area", val: pestData.affectedArea },
              { key: "Infestation Stage", val: pestData.stage },
            ].map((item) => (
              <div key={item.key} className="rounded-xl p-3" style={{ background: "#F8F8F8" }}>
                <p style={{ color: "#888", fontSize: 10, marginBottom: 3 }}>{item.key}</p>
                <p style={{ fontWeight: 600, fontSize: 12, color: "#333" }}>{item.val}</p>
              </div>
            ))}
          </div>

          <div className="mt-3">
            <p style={{ fontSize: 12, color: "#888", marginBottom: 6 }}>Key Symptoms</p>
            {pestData.symptoms.map((s) => (
              <div key={s} className="flex items-start gap-2 mb-1.5">
                <CheckCircle2 size={13} color="#C62828" className="flex-shrink-0 mt-0.5" />
                <span style={{ fontSize: 12, color: "#444", lineHeight: 1.5 }}>{s}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="mx-4 mt-4">
          <div className="flex rounded-xl p-1 mb-4" style={{ background: "#E8E8E8" }}>
            {[
              { key: "organic", label: "🌿 Organic Treatment" },
              { key: "prevention", label: "🛡️ Prevention" },
              { key: "districts", label: "📍 Nearby Risk" },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as typeof activeTab)}
                className="flex-1 py-2.5 rounded-lg text-center"
                style={{
                  background: activeTab === tab.key ? "#fff" : "transparent",
                  color: activeTab === tab.key ? "#1B5E20" : "#666",
                  fontWeight: activeTab === tab.key ? 700 : 400,
                  fontSize: 11,
                  boxShadow: activeTab === tab.key ? "0 2px 8px rgba(0,0,0,0.08)" : "none",
                  transition: "all 0.2s ease",
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Organic Treatment */}
          {activeTab === "organic" && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col gap-3"
            >
              {pestData.organicTreatments.map((treatment, i) => (
                <motion.div
                  key={treatment.title}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                  className="rounded-2xl p-4"
                  style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className="flex items-center justify-center rounded-2xl flex-shrink-0"
                      style={{ width: 44, height: 44, background: "#E8F5E9", fontSize: 22 }}
                    >
                      {treatment.icon}
                    </div>
                    <div className="flex-1">
                      <h3 style={{ fontWeight: 700, fontSize: 14, color: "#1a1a1a", marginBottom: 4 }}>{treatment.title}</h3>
                      <p style={{ fontSize: 12, color: "#666", lineHeight: 1.5, marginBottom: 8 }}>{treatment.desc}</p>
                      <div className="flex items-center gap-2">
                        <span style={{ fontSize: 11, color: "#888" }}>Effectiveness:</span>
                        <div className="flex-1 rounded-full overflow-hidden" style={{ height: 5, background: "#F0F0F0" }}>
                          <div
                            className="h-full rounded-full"
                            style={{ width: `${treatment.effectiveness}%`, background: "linear-gradient(90deg, #2E7D32, #66BB6A)" }}
                          />
                        </div>
                        <span style={{ fontSize: 11, fontWeight: 600, color: "#2E7D32" }}>{treatment.effectiveness}%</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}

          {/* Prevention */}
          {activeTab === "prevention" && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl p-5"
              style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
            >
              <div className="flex items-center gap-2 mb-4">
                <Leaf size={16} color="#2E7D32" />
                <h3 style={{ fontWeight: 700, fontSize: 15, color: "#1B5E20" }}>Prevention Strategies</h3>
              </div>
              {pestData.prevention.map((item, i) => (
                <motion.div
                  key={item}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.07 }}
                  className="flex items-start gap-3 mb-3 p-3 rounded-xl"
                  style={{ background: "#F8FAF9", border: "1px solid #E8F5E9" }}
                >
                  <div
                    className="rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ width: 22, height: 22, background: "#E8F5E9", color: "#2E7D32", fontSize: 11, fontWeight: 700 }}
                  >
                    {i + 1}
                  </div>
                  <span style={{ fontSize: 13, color: "#444", lineHeight: 1.5 }}>{item}</span>
                </motion.div>
              ))}
            </motion.div>
          )}

          {/* Nearby Districts */}
          {activeTab === "districts" && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col gap-3"
            >
              <div
                className="rounded-2xl p-4"
                style={{ background: "#FFF8E1", border: "1.5px solid #FFD54F" }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <Info size={14} color="#E65100" />
                  <span style={{ fontWeight: 700, fontSize: 13, color: "#E65100" }}>Regional Pest Alert</span>
                </div>
                <p style={{ fontSize: 12, color: "#555", lineHeight: 1.5 }}>
                  Fall Armyworm is currently active in 3 nearby districts. Take preventive action immediately.
                </p>
              </div>

              {pestData.nearbyDistricts.map((d, i) => (
                <motion.div
                  key={d.name}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="rounded-2xl p-4 flex items-center gap-3"
                  style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
                >
                  <div className="rounded-xl p-2" style={{ background: `${d.color}15` }}>
                    <AlertTriangle size={18} color={d.color} />
                  </div>
                  <div className="flex-1">
                    <p style={{ fontWeight: 600, fontSize: 14, color: "#1a1a1a" }}>{d.name} District</p>
                    <p style={{ fontSize: 11, color: "#888" }}>Tamil Nadu</p>
                  </div>
                  <span
                    className="px-3 py-1 rounded-full"
                    style={{ background: `${d.color}15`, color: d.color, fontSize: 11, fontWeight: 700 }}
                  >
                    {d.risk} Risk
                  </span>
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="mx-4 mt-6 flex flex-col gap-3">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => navigate("/chat")}
            className="w-full py-4 rounded-2xl flex items-center justify-center gap-2"
            style={{
              background: "linear-gradient(135deg, #1B5E20, #2E7D32)",
              color: "#fff",
              fontSize: 15,
              fontWeight: 700,
              boxShadow: "0 6px 20px rgba(46,125,50,0.35)",
            }}
          >
            <MessageCircle size={18} /> Chat with AI about this
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => navigate("/knowledge")}
            className="w-full py-4 rounded-2xl flex items-center justify-center gap-2"
            style={{
              background: "#fff",
              border: "1.5px solid #2E7D32",
              color: "#2E7D32",
              fontSize: 15,
              fontWeight: 600,
            }}
          >
            <BookOpen size={18} /> View Full Treatment Guide
          </motion.button>
        </div>
      </div>
    </div>
  );
}
