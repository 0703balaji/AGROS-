import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  Mic, Camera, Send, Leaf, ChevronLeft, Volume2, Copy, ThumbsUp,
  Sparkles, MoreHorizontal, Image, Loader
} from "lucide-react";
import { MobileLayout } from "../components/MobileLayout";
import { PremiumCard } from "../components/PremiumCard";

interface Message {
  id: string;
  type: "user" | "ai";
  content: string;
  timestamp: Date;
  hasImage?: boolean;
  imageUrl?: string;
}

const SUGGESTIONS = [
  "What crops should I grow this season?",
  "Pest on my tomato leaves, how to treat?",
  "Best organic fertilizer for rice?",
  "How to manage waterlogging in fields?",
];

const AI_RESPONSES: Record<string, string> = {
  default: `Namaste! 🙏 I'm KrishiAI, your smart farming assistant.

I can help you with:
• 🌾 Crop selection & recommendations
• 🐛 Pest & disease identification
• 🌱 Soil health & fertilizer advice
• 🌧 Weather-based farming tips
• 📊 District-specific insights

What would you like to know today?`,

  crop: `Based on your location in Thanjavur, Tamil Nadu and the current Kharif season, I recommend:

🌾 **Top Crops for Your District:**

1. **Paddy (IR-64 variety)**
   • Yield: 5-6 tonnes/acre
   • Market price: ₹2,183/quintal
   • Pest risk: Medium (Fall Armyworm alert)

2. **Black-eyed Peas**
   • Excellent for soil nitrogen fixation
   • Water-efficient crop
   • Good inter-cropping option

3. **Groundnut**
   • High market demand
   • Suitable for red sandy loam soil

**My Recommendation:** Continue with paddy but use pest-resistant varieties like TRY3 or ADT45.

Want me to explain the cultivation schedule? 🌱`,

  pest: `⚠️ Based on your description, this sounds like **Fall Armyworm** (*Spodoptera frugiperda*).

**Identification Signs:**
• Ragged holes in leaves
• Frass (droppings) visible
• Young worms in leaf funnels

**Immediate Action (Organic):**

1. 🌿 **Neem Oil Spray**
   Mix: 5ml neem oil + 1ml soap per liter water
   Apply: Early morning or evening

2. 🦠 **Bt Spray** (Bacillus thuringiensis)
   Apply: 1g per liter water

3. ✂️ Remove and destroy heavily infested plants

4. 🪤 **Pheromone Traps**
   Set 5 traps per acre for monitoring

**Follow-up:** Monitor every 3 days. If damage exceeds 30%, consult your local agricultural officer.

Need the treatment schedule? 📅`,

  soil: `🌱 **Soil Health Analysis for Thanjavur:**

Based on typical clay loam soil in your district:

**Current Status:**
• pH: 6.8 (Optimal ✅)
• Organic Carbon: 0.45% (Low ⚠️)
• Nitrogen: Medium
• Phosphorus: Low

**Recommended Organic Amendments:**

1. **Green Manure** (Sesbania)
   Apply before paddy transplanting

2. **FYM (Farmyard Manure)**
   5 tonnes/acre before last ploughing

3. **Vermicompost**
   1 tonne/acre for high-value crops

4. **Azospirillum Bio-fertilizer**
   2 packets (200g) per acre for nitrogen fixation

**Result:** Improving organic carbon can increase yield by 15-20% over 2 seasons.

Want a detailed soil improvement plan? 🗓️`,
};

function getAIResponse(msg: string): string {
  const lower = msg.toLowerCase();
  if (lower.includes("crop") || lower.includes("grow") || lower.includes("season")) return AI_RESPONSES.crop;
  if (lower.includes("pest") || lower.includes("insect") || lower.includes("bug") || lower.includes("worm")) return AI_RESPONSES.pest;
  if (lower.includes("soil") || lower.includes("fertilizer") || lower.includes("organic")) return AI_RESPONSES.soil;
  return AI_RESPONSES.default;
}

function TypingIndicator() {
  return (
    <div className="flex items-center gap-1.5 px-4 py-3 rounded-2xl rounded-tl-none" style={{ background: "#fff", boxShadow: "0 2px 12px rgba(0,0,0,0.08)", width: "fit-content" }}>
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="rounded-full"
          style={{ width: 7, height: 7, background: "#2E7D32" }}
          animate={{ y: [0, -6, 0] }}
          transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
        />
      ))}
    </div>
  );
}

function formatMessageContent(content: string) {
  const parts = content.split(/(\*\*.*?\*\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return <strong key={i}>{part.slice(2, -2)}</strong>;
    }
    return <span key={i}>{part}</span>;
  });
}

export function ChatPage() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      type: "ai",
      content: AI_RESPONSES.default,
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const sendMessage = async (text?: string) => {
    const messageText = text || input.trim();
    if (!messageText) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      type: "user",
      content: messageText,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setShowSuggestions(false);
    setIsTyping(true);

    setTimeout(() => {
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        type: "ai",
        content: getAIResponse(messageText),
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiMsg]);
      setIsTyping(false);
    }, 1800);
  };

  return (
    <MobileLayout>
      {/* Header */}
      <div
        className="sticky top-0 z-40 px-4 py-3 flex items-center gap-3"
        style={{
          background: "rgba(255,255,255,0.96)",
          backdropFilter: "blur(20px)",
          borderBottom: "1px solid rgba(0,0,0,0.06)",
          boxShadow: "0 2px 12px rgba(0,0,0,0.05)",
        }}
      >
        <button onClick={() => navigate("/dashboard")} className="rounded-xl p-2" style={{ background: "#F5F5F5" }}>
          <ChevronLeft size={20} color="#333" />
        </button>

        <div className="flex items-center gap-3 flex-1">
          <div
            className="rounded-2xl flex items-center justify-center"
            style={{ width: 40, height: 40, background: "linear-gradient(135deg, #1B5E20, #2E7D32)", boxShadow: "0 4px 12px rgba(46,125,50,0.3)" }}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M12 2C8 2 4 5 4 9c0 5 5 9 8 11 3-2 8-6 8-11 0-4-4-7-8-7z" fill="#A5D6A7" />
              <circle cx="12" cy="9" r="2" fill="#fff" />
            </svg>
          </div>
          <div>
            <div style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 15, color: "#1B5E20" }}>KrishiAI</div>
            <div className="flex items-center gap-1.5">
              <div className="rounded-full" style={{ width: 7, height: 7, background: "#4CAF50" }} />
              <span style={{ color: "#4CAF50", fontSize: 11, fontWeight: 600 }}>Online</span>
              <span style={{ color: "#888", fontSize: 11 }}>· Thanjavur, Tamil Nadu</span>
            </div>
          </div>
        </div>

        <button className="rounded-xl p-2" style={{ background: "#F5F5F5" }}>
          <MoreHorizontal size={20} color="#555" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 px-4 py-4 overflow-y-auto" style={{ minHeight: 0 }}>
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 16, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.3, ease: [0.25, 0.46, 0.45, 0.94] }}
              className={`flex gap-3 mb-5 ${msg.type === "user" ? "flex-row-reverse" : ""}`}
            >
              {msg.type === "ai" && (
                <div
                  className="flex-shrink-0 rounded-2xl flex items-center justify-center"
                  style={{ width: 34, height: 34, background: "linear-gradient(135deg, #1B5E20, #2E7D32)", alignSelf: "flex-end" }}
                >
                  <Leaf size={16} color="#fff" />
                </div>
              )}

              <div className={`max-w-[80%] ${msg.type === "user" ? "items-end" : "items-start"} flex flex-col gap-1`}>
                <div
                  className="px-4 py-3 rounded-2xl"
                  style={
                    msg.type === "user"
                      ? {
                          background: "linear-gradient(135deg, #2E7D32, #43A047)",
                          borderRadius: "18px 18px 4px 18px",
                          boxShadow: "0 4px 12px rgba(46,125,50,0.25)",
                        }
                      : {
                          background: "#fff",
                          borderRadius: "18px 18px 18px 4px",
                          boxShadow: "0 2px 12px rgba(0,0,0,0.08)",
                        }
                  }
                >
                  <p
                    style={{
                      fontSize: 13.5,
                      lineHeight: 1.65,
                      color: msg.type === "user" ? "#fff" : "#222",
                      whiteSpace: "pre-line",
                    }}
                  >
                    {formatMessageContent(msg.content)}
                  </p>
                </div>

                {msg.type === "ai" && (
                  <div className="flex items-center gap-2 px-1">
                    {[
                      { icon: Volume2, label: "Listen" },
                      { icon: Copy, label: "Copy" },
                      { icon: ThumbsUp, label: "Helpful" },
                    ].map((action) => (
                      <button
                        key={action.label}
                        className="flex items-center gap-1 py-1 px-2 rounded-lg"
                        style={{ background: "transparent", color: "#888", fontSize: 11 }}
                      >
                        <action.icon size={12} />
                        <span>{action.label}</span>
                      </button>
                    ))}
                  </div>
                )}

                <span style={{ fontSize: 10, color: "#bbb", paddingLeft: 4 }}>
                  {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing Indicator */}
        {isTyping && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex gap-3 mb-4"
          >
            <div className="rounded-2xl flex items-center justify-center" style={{ width: 34, height: 34, background: "linear-gradient(135deg, #1B5E20, #2E7D32)", flexShrink: 0 }}>
              <Leaf size={16} color="#fff" />
            </div>
            <TypingIndicator />
          </motion.div>
        )}

        {/* Suggestions */}
        {showSuggestions && !isTyping && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4"
          >
            <p style={{ fontSize: 12, color: "#888", marginBottom: 10, paddingLeft: 2 }}>Quick questions:</p>
            <div className="flex flex-col gap-2">
              {SUGGESTIONS.map((s) => (
                <motion.button
                  key={s}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => sendMessage(s)}
                  className="text-left px-4 py-3 rounded-2xl"
                  style={{
                    background: "#fff",
                    border: "1.5px solid #E8F5E9",
                    color: "#2E7D32",
                    fontSize: 13,
                    fontWeight: 500,
                    boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
                  }}
                >
                  {s}
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Bar */}
      <div
        className="sticky bottom-20 left-0 right-0 px-4 py-3"
        style={{
          background: "rgba(248,250,249,0.98)",
          backdropFilter: "blur(20px)",
          borderTop: "1px solid rgba(0,0,0,0.06)",
        }}
      >
        <div
          className="flex items-center gap-2 px-3 py-2 rounded-2xl"
          style={{
            background: "#fff",
            border: "1.5px solid #E0E0E0",
            boxShadow: "0 4px 16px rgba(0,0,0,0.08)",
          }}
        >
          {/* Voice Button */}
          <motion.button
            whileTap={{ scale: 0.9 }}
            className="flex-shrink-0 flex items-center justify-center rounded-xl"
            style={{ width: 36, height: 36, background: "#E8F5E9" }}
          >
            <Mic size={18} color="#2E7D32" />
          </motion.button>

          <input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            placeholder="Ask about crops, pests, soil health or weather..."
            className="flex-1 outline-none bg-transparent"
            style={{ fontSize: 13, color: "#333" }}
          />

          {/* Camera Button */}
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => navigate("/scan")}
            className="flex-shrink-0 flex items-center justify-center rounded-xl"
            style={{ width: 36, height: 36, background: "#FFF8E1" }}
          >
            <Camera size={18} color="#F57F17" />
          </motion.button>

          {/* Send Button */}
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => sendMessage()}
            disabled={!input.trim() && !isTyping}
            className="flex-shrink-0 flex items-center justify-center rounded-xl"
            style={{
              width: 36,
              height: 36,
              background: input.trim() ? "linear-gradient(135deg, #2E7D32, #66BB6A)" : "#E0E0E0",
              transition: "all 0.2s ease",
              boxShadow: input.trim() ? "0 4px 12px rgba(46,125,50,0.3)" : "none",
            }}
          >
            <Send size={16} color={input.trim() ? "#fff" : "#999"} />
          </motion.button>
        </div>

        <div className="flex justify-center gap-6 mt-2">
          {[
            { icon: Mic, label: "Voice" },
            { icon: Camera, label: "Camera" },
            { icon: Image, label: "Gallery" },
          ].map((btn) => (
            <button
              key={btn.label}
              className="flex items-center gap-1"
              style={{ color: "#888", fontSize: 11 }}
              onClick={btn.label === "Camera" ? () => navigate("/scan") : undefined}
            >
              <btn.icon size={12} />
              {btn.label}
            </button>
          ))}
        </div>
      </div>
    </MobileLayout>
  );
}