import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  ChevronLeft, CloudRain, Thermometer, Droplets, Bug, Leaf, ShoppingCart,
  TrendingUp, TrendingDown, BarChart3, MapPin, AlertTriangle, Sun, Wind, ChevronRight
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip, RadarChart,
  PolarGrid, PolarAngleAxis, Radar, BarChart, Bar, Legend
} from "recharts";
import { MobileLayout } from "../components/MobileLayout";
import { MobileHeader } from "../components/MobileHeader";

const soilData = [
  { nutrient: "Nitrogen", value: 65, optimal: 80, id: "soil-n" },
  { nutrient: "Phosphorus", value: 42, optimal: 70, id: "soil-p" },
  { nutrient: "Potassium", value: 78, optimal: 85, id: "soil-k" },
  { nutrient: "Organic C", value: 38, optimal: 65, id: "soil-oc" },
  { nutrient: "pH Level", value: 72, optimal: 75, id: "soil-ph" },
  { nutrient: "Moisture", value: 55, optimal: 70, id: "soil-m" },
];

const weeklyWeather = [
  { day: "Mon", temp: 31, rain: 2, id: "weather-mon" },
  { day: "Tue", temp: 33, rain: 0, id: "weather-tue" },
  { day: "Wed", temp: 29, rain: 8, id: "weather-wed" },
  { day: "Thu", temp: 28, rain: 12, id: "weather-thu" },
  { day: "Fri", temp: 30, rain: 5, id: "weather-fri" },
  { day: "Sat", temp: 32, rain: 1, id: "weather-sat" },
  { day: "Sun", temp: 34, rain: 0, id: "weather-sun" },
];

const cropRecommendations = [
  { name: "Paddy (IR-64)", suitability: 95, season: "Kharif", water: "High", icon: "🌾", id: "crop-rec-paddy" },
  { name: "Black-eyed Peas", suitability: 88, season: "Rabi", water: "Low", icon: "🫘", id: "crop-rec-peas" },
  { name: "Groundnut", suitability: 82, season: "Both", water: "Medium", icon: "🥜", id: "crop-rec-groundnut" },
  { name: "Sugarcane", suitability: 78, season: "Perennial", water: "High", icon: "🎋", id: "crop-rec-sugarcane" },
  { name: "Vegetables", suitability: 73, season: "Rabi", water: "Medium", icon: "🥦", id: "crop-rec-veg" },
];

const marketData = [
  { month: "Sep", rice: 2100, wheat: 2180, cotton: 6400, id: "market-sep" },
  { month: "Oct", rice: 2150, wheat: 2200, cotton: 6550, id: "market-oct" },
  { month: "Nov", rice: 2183, wheat: 2245, cotton: 6620, id: "market-nov" },
  { month: "Dec", rice: 2210, wheat: 2275, cotton: 6580, id: "market-dec" },
];

const SOIL_IMG = "https://images.unsplash.com/photo-1737960320564-9e681df95dc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2lsJTIwaGVhbHRoJTIwb3JnYW5pYyUyMGZhcm1pbmclMjBoYW5kc3xlbnwxfHx8fDE3NzI4MTMwNzl8MA&ixlib=rb-4.1.0&q=80&w=1080";

const TABS = ["Overview", "Crops", "Soil", "Market", "Weather"];

export function InsightsPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("Overview");

  return (
    <MobileLayout>
      <MobileHeader />

      <div className="px-4 py-4">
        {/* District Card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl overflow-hidden mb-4 relative"
          style={{ height: 130 }}
        >
          <img src={SOIL_IMG} alt="District" className="w-full h-full object-cover" />
          <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(27,94,32,0.85), rgba(0,0,0,0.4))" }} />
          <div className="absolute inset-0 p-4 flex flex-col justify-between">
            <div className="flex items-center gap-2">
              <MapPin size={14} color="#A5D6A7" />
              <span style={{ color: "rgba(255,255,255,0.85)", fontSize: 12 }}>Thanjavur District, Tamil Nadu</span>
            </div>
            <div>
              <h2 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 18, color: "#fff", marginBottom: 4 }}>
                District Intelligence
              </h2>
              <div className="flex gap-3">
                {[
                  { label: "Clay Loam Soil", color: "#A5D6A7" },
                  { label: "Kharif Season", color: "#FFC107" },
                  { label: "Irrigation: Good", color: "#81D4FA" },
                ].map((badge) => (
                  <span
                    key={badge.label}
                    className="px-2 py-0.5 rounded-full"
                    style={{ background: "rgba(255,255,255,0.15)", color: badge.color, fontSize: 10, fontWeight: 600 }}
                  >
                    {badge.label}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1 mb-4" style={{ scrollbarWidth: "none" }}>
          {TABS.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className="flex-shrink-0 px-4 py-2 rounded-xl"
              style={{
                background: activeTab === tab ? "#1B5E20" : "#fff",
                color: activeTab === tab ? "#fff" : "#555",
                fontWeight: activeTab === tab ? 700 : 400,
                fontSize: 13,
                border: activeTab === tab ? "none" : "1.5px solid #E0E0E0",
                boxShadow: activeTab === tab ? "0 4px 12px rgba(27,94,32,0.25)" : "none",
                transition: "all 0.2s ease",
              }}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* OVERVIEW */}
        {activeTab === "Overview" && (
          <div>
            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              {[
                { icon: Thermometer, label: "Avg Temperature", value: "31°C", sub: "2° above normal", color: "#E65100", bg: "#FFF3E0" },
                { icon: Droplets, label: "Soil Moisture", value: "55%", sub: "Below optimal", color: "#1565C0", bg: "#E3F2FD" },
                { icon: Bug, label: "Pest Risk Level", value: "High", sub: "3 alerts active", color: "#C62828", bg: "#FFEBEE" },
                { icon: Leaf, label: "Crop Suitability", value: "95%", sub: "Paddy ideal", color: "#2E7D32", bg: "#E8F5E9" },
              ].map((stat) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="rounded-2xl p-4"
                  style={{ background: stat.bg, boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }}
                >
                  <stat.icon size={20} color={stat.color} />
                  <p style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: 22, color: stat.color, marginTop: 8 }}>
                    {stat.value}
                  </p>
                  <p style={{ fontWeight: 600, fontSize: 11, color: "#333" }}>{stat.label}</p>
                  <p style={{ fontSize: 10, color: "#888" }}>{stat.sub}</p>
                </motion.div>
              ))}
            </div>

            {/* Pest Alert */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="rounded-2xl p-4 mb-4"
              style={{ background: "#FFEBEE", border: "1.5px solid #EF9A9A" }}
            >
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle size={16} color="#C62828" />
                <span style={{ fontWeight: 700, fontSize: 14, color: "#B71C1C" }}>Active Pest Alerts</span>
              </div>
              {[
                { name: "Fall Armyworm", severity: "High", crop: "Paddy" },
                { name: "Leaf Folder", severity: "Medium", crop: "Rice" },
              ].map((pest) => (
                <div
                  key={pest.name}
                  className="flex items-center justify-between p-2.5 rounded-xl mb-2"
                  style={{ background: "rgba(255,255,255,0.6)" }}
                >
                  <div>
                    <p style={{ fontWeight: 600, fontSize: 13, color: "#1a1a1a" }}>{pest.name}</p>
                    <p style={{ fontSize: 11, color: "#888" }}>Affects {pest.crop}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className="px-2 py-0.5 rounded-full"
                      style={{ background: pest.severity === "High" ? "#C62828" : "#E65100", color: "#fff", fontSize: 10, fontWeight: 700 }}
                    >
                      {pest.severity}
                    </span>
                    <button onClick={() => navigate("/pest-results")}>
                      <ChevronRight size={16} color="#888" />
                    </button>
                  </div>
                </div>
              ))}
            </motion.div>

            {/* Today's Weather */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="rounded-2xl p-4 mb-4"
              style={{ background: "linear-gradient(135deg, #1565C0, #1976D2)", boxShadow: "0 6px 20px rgba(21,101,192,0.25)" }}
            >
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 11 }}>Today's Weather</p>
                  <div className="flex items-end gap-2">
                    <span style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 34, color: "#fff" }}>32°C</span>
                    <span style={{ color: "rgba(255,255,255,0.8)", fontSize: 13, marginBottom: 5 }}>Partly Cloudy</span>
                  </div>
                </div>
                <Sun size={40} color="#FFC107" />
              </div>

              <div className="flex gap-4 flex-wrap">
                {[
                  { icon: Droplets, label: "Humidity", val: "74%" },
                  { icon: Wind, label: "Wind", val: "12 km/h" },
                  { icon: CloudRain, label: "Rain", val: "18mm" },
                ].map((w) => (
                  <div key={w.label} className="flex items-center gap-1.5">
                    <w.icon size={12} color="rgba(255,255,255,0.7)" />
                    <div>
                      <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 9 }}>{w.label}</p>
                      <p style={{ color: "#fff", fontSize: 11, fontWeight: 600 }}>{w.val}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        )}

        {/* CROPS Tab */}
        {activeTab === "Crops" && (
          <div>
            <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 15, color: "#1B5E20", marginBottom: 12 }}>
              Recommended Crops for Thanjavur
            </h3>
            {cropRecommendations.map((crop, i) => (
              <motion.div
                key={crop.name}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
                className="rounded-2xl p-4 mb-3 flex items-center gap-4"
                style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
              >
                <div
                  className="rounded-2xl flex items-center justify-center flex-shrink-0"
                  style={{ width: 52, height: 52, background: "#E8F5E9", fontSize: 26 }}
                >
                  {crop.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <p style={{ fontWeight: 700, fontSize: 14, color: "#1a1a1a" }}>{crop.name}</p>
                    <span style={{ fontWeight: 800, fontSize: 15, color: "#2E7D32" }}>{crop.suitability}%</span>
                  </div>
                  <div className="rounded-full overflow-hidden mb-2" style={{ height: 5, background: "#F0F0F0" }}>
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${crop.suitability}%` }}
                      transition={{ delay: i * 0.08 + 0.3, duration: 0.7 }}
                      className="h-full rounded-full"
                      style={{ background: "linear-gradient(90deg, #2E7D32, #66BB6A)" }}
                    />
                  </div>
                  <div className="flex gap-3">
                    <span style={{ fontSize: 10, color: "#888" }}>Season: <strong style={{ color: "#555" }}>{crop.season}</strong></span>
                    <span style={{ fontSize: 10, color: "#888" }}>Water: <strong style={{ color: "#555" }}>{crop.water}</strong></span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* SOIL Tab */}
        {activeTab === "Soil" && (
          <div>
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl p-4 mb-4"
              style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
            >
              <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 15, color: "#1B5E20", marginBottom: 16 }}>
                Soil Nutrient Profile
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <RadarChart data={soilData}>
                  <PolarGrid stroke="#E0E0E0" />
                  <PolarAngleAxis dataKey="nutrient" tick={{ fontSize: 11, fill: "#666" }} />
                  <Radar name="Current" dataKey="value" stroke="#2E7D32" fill="#2E7D32" fillOpacity={0.25} strokeWidth={2} />
                  <Radar name="Optimal" dataKey="optimal" stroke="#795548" fill="#795548" fillOpacity={0.1} strokeWidth={1.5} strokeDasharray="4 4" />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Tooltip contentStyle={{ background: "#fff", borderRadius: 10, fontSize: 11, border: "none", boxShadow: "0 4px 16px rgba(0,0,0,0.1)" }} />
                </RadarChart>
              </ResponsiveContainer>
            </motion.div>

            {soilData.map((nutrient, i) => (
              <motion.div
                key={nutrient.nutrient}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.07 }}
                className="rounded-xl p-4 mb-3 flex items-center gap-3"
                style={{ background: "#fff", boxShadow: "0 2px 10px rgba(0,0,0,0.05)" }}
              >
                <div className="flex-1">
                  <div className="flex justify-between mb-1.5">
                    <span style={{ fontWeight: 600, fontSize: 13, color: "#333" }}>{nutrient.nutrient}</span>
                    <span style={{ fontWeight: 700, fontSize: 13, color: nutrient.value >= nutrient.optimal * 0.8 ? "#2E7D32" : "#E65100" }}>
                      {nutrient.value}/{nutrient.optimal}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 rounded-full overflow-hidden" style={{ height: 6, background: "#F0F0F0" }}>
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${(nutrient.value / nutrient.optimal) * 100}%`,
                          background: nutrient.value >= nutrient.optimal * 0.8 ? "linear-gradient(90deg, #2E7D32, #66BB6A)" : "linear-gradient(90deg, #E65100, #FFC107)",
                        }}
                      />
                    </div>
                    <span style={{ fontSize: 10, color: "#888", minWidth: 30 }}>
                      {Math.round((nutrient.value / nutrient.optimal) * 100)}%
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* MARKET Tab */}
        {activeTab === "Market" && (
          <div>
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl p-4 mb-4"
              style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
            >
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 size={16} color="#795548" />
                <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 14, color: "#1a1a1a" }}>
                  Crop Price Trends (₹/quintal)
                </h3>
              </div>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={marketData} barSize={16}>
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#888" }} axisLine={false} tickLine={false} />
                  <YAxis hide domain={[2000, 7000]} />
                  <Tooltip contentStyle={{ background: "#fff", borderRadius: 10, fontSize: 11, border: "none", boxShadow: "0 4px 16px rgba(0,0,0,0.1)" }} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="rice" fill="#2E7D32" name="Rice" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="wheat" fill="#795548" name="Wheat" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="cotton" fill="#FFC107" name="Cotton" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </motion.div>

            {[
              { crop: "Rice (Paddy)", price: "₹2,183", change: "+2.3%", up: true, forecast: "Price expected to rise ↑" },
              { crop: "Wheat", price: "₹2,275", change: "+0.8%", up: true, forecast: "Stable market outlook" },
              { crop: "Cotton", price: "₹6,620", change: "-1.2%", up: false, forecast: "Hold, price may recover" },
              { crop: "Groundnut", price: "₹5,440", change: "+3.1%", up: true, forecast: "Best time to sell ↑" },
            ].map((item, i) => (
              <motion.div
                key={item.crop}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="rounded-2xl p-4 mb-3"
                style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <ShoppingCart size={16} color="#795548" />
                    <p style={{ fontWeight: 600, fontSize: 14, color: "#1a1a1a" }}>{item.crop}</p>
                  </div>
                  <div className="text-right">
                    <p style={{ fontWeight: 800, fontSize: 15, color: "#1a1a1a" }}>{item.price}</p>
                    <div className="flex items-center gap-1 justify-end">
                      {item.up ? <TrendingUp size={12} color="#2E7D32" /> : <TrendingDown size={12} color="#C62828" />}
                      <span style={{ fontSize: 11, fontWeight: 600, color: item.up ? "#2E7D32" : "#C62828" }}>{item.change}</span>
                    </div>
                  </div>
                </div>
                <p style={{ fontSize: 11, color: "#888", padding: "6px 8px", background: item.up ? "#E8F5E9" : "#FFEBEE", borderRadius: 8, display: "inline-block" }}>
                  {item.up ? "📈" : "📉"} {item.forecast}
                </p>
              </motion.div>
            ))}
          </div>
        )}

        {/* WEATHER Tab */}
        {activeTab === "Weather" && (
          <div>
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl p-4 mb-4"
              style={{ background: "linear-gradient(135deg, #1565C0, #0D47A1)", boxShadow: "0 8px 24px rgba(21,101,192,0.3)" }}
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>Thanjavur, TN</p>
                  <p style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 800, fontSize: 48, color: "#fff" }}>32°</p>
                  <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 14 }}>Partly Cloudy</p>
                </div>
                <Sun size={56} color="#FFC107" />
              </div>

              <div className="grid grid-cols-4 gap-2">
                {weeklyWeather.slice(0, 4).map((day) => (
                  <div key={day.day} className="text-center p-2 rounded-xl" style={{ background: "rgba(255,255,255,0.1)" }}>
                    <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 10 }}>{day.day}</p>
                    <Sun size={18} color="#FFC107" className="mx-auto my-1" />
                    <p style={{ color: "#fff", fontWeight: 700, fontSize: 13 }}>{day.temp}°</p>
                    {day.rain > 0 && <p style={{ color: "#90CAF9", fontSize: 9 }}>{day.rain}mm</p>}
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="rounded-2xl p-4 mb-4"
              style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
            >
              <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 14, color: "#1a1a1a", marginBottom: 16 }}>
                Rainfall Forecast (mm)
              </h3>
              <ResponsiveContainer width="100%" height={150}>
                <AreaChart data={weeklyWeather}>
                  <defs>
                    <linearGradient id="rainGrad2" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#1565C0" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#1565C0" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <Tooltip contentStyle={{ background: "#fff", borderRadius: 10, fontSize: 11, border: "none", boxShadow: "0 4px 16px rgba(0,0,0,0.1)" }} formatter={(val) => [`${val}mm`, "Rain"]} />
                  <Area type="monotone" dataKey="rain" stroke="#1565C0" strokeWidth={2} fill="url(#rainGrad2)" dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </motion.div>

            {/* Farming Calendar */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="rounded-2xl p-4"
              style={{ background: "#fff", boxShadow: "0 4px 16px rgba(0,0,0,0.06)" }}
            >
              <h3 style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 14, color: "#1B5E20", marginBottom: 12 }}>
                Weather-Based Farming Tips
              </h3>
              {[
                { emoji: "🌧", tip: "Light rain expected Thursday. Delay irrigation by 2 days.", type: "info" },
                { emoji: "☀️", tip: "High UV index this week. Water crops early morning.", type: "warning" },
                { emoji: "💨", tip: "Strong winds Saturday. Avoid pesticide spraying.", type: "warning" },
                { emoji: "🌱", tip: "Good soil moisture today. Ideal for transplanting.", type: "success" },
              ].map((item) => (
                <div
                  key={item.tip}
                  className="flex items-start gap-3 p-3 rounded-xl mb-2"
                  style={{
                    background: item.type === "info" ? "#E3F2FD" : item.type === "warning" ? "#FFF8E1" : "#E8F5E9",
                    border: `1px solid ${item.type === "info" ? "#BBDEFB" : item.type === "warning" ? "#FFE082" : "#A5D6A7"}`,
                  }}
                >
                  <span style={{ fontSize: 18 }}>{item.emoji}</span>
                  <p style={{ fontSize: 12, color: "#333", lineHeight: 1.5 }}>{item.tip}</p>
                </div>
              ))}
            </motion.div>
          </div>
        )}
      </div>
    </MobileLayout>
  );
}