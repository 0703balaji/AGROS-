import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Zap, Image, FlipHorizontal, Circle, CheckCircle2, X } from "lucide-react";

const SCAN_IMG = "https://images.unsplash.com/photo-1694100223107-c898e5c117c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbGFudCUyMGxlYWYlMjBkaXNlYXNlJTIwcGVzdCUyMGNsb3NldXB8ZW58MXx8fHwxNzcyODEzMDc5fDA&ixlib=rb-4.1.0&q=80&w=1080";

type Phase = "camera" | "captured" | "analyzing" | "done";

export function ScanPage() {
  const navigate = useNavigate();
  const [phase, setPhase] = useState<Phase>("camera");
  const [flashOn, setFlashOn] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanLineY, setScanLineY] = useState(0);

  // Scan line animation
  useEffect(() => {
    if (phase !== "analyzing") return;
    let dir = 1;
    let y = 0;
    const interval = setInterval(() => {
      y += dir * 3;
      if (y > 100) dir = -1;
      if (y < 0) dir = 1;
      setScanLineY(y);
    }, 30);
    return () => clearInterval(interval);
  }, [phase]);

  // Progress
  useEffect(() => {
    if (phase !== "analyzing") return;
    let p = 0;
    const interval = setInterval(() => {
      p += Math.random() * 8;
      if (p >= 100) {
        p = 100;
        clearInterval(interval);
        setTimeout(() => navigate("/pest-results"), 500);
      }
      setScanProgress(p);
    }, 150);
    return () => clearInterval(interval);
  }, [phase]);

  const handleCapture = () => {
    setPhase("captured");
  };

  const handleAnalyze = () => {
    setPhase("analyzing");
  };

  return (
    <div
      className="min-h-screen flex flex-col relative"
      style={{ background: "#000", fontFamily: "'Inter', sans-serif" }}
    >
      {/* Top Bar */}
      <div
        className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-5 py-4"
        style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.7), transparent)" }}
      >
        <button
          onClick={() => navigate(-1)}
          className="flex items-center justify-center rounded-xl"
          style={{ width: 40, height: 40, background: "rgba(255,255,255,0.15)", backdropFilter: "blur(10px)" }}
        >
          <ChevronLeft size={22} color="#fff" />
        </button>

        <div className="text-center">
          <p style={{ color: "#fff", fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 15 }}>
            {phase === "camera" ? "AI Crop Scanner" : phase === "captured" ? "Review Photo" : "Analyzing..."}
          </p>
          <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 11 }}>
            {phase === "camera" ? "Capture crop or pest image" : phase === "captured" ? "Looks good? Tap Analyze" : "AI is processing your image"}
          </p>
        </div>

        <button
          onClick={() => setFlashOn(!flashOn)}
          className="flex items-center justify-center rounded-xl"
          style={{
            width: 40,
            height: 40,
            background: flashOn ? "rgba(255,193,7,0.3)" : "rgba(255,255,255,0.15)",
            backdropFilter: "blur(10px)",
            border: flashOn ? "1.5px solid #FFC107" : "none",
          }}
        >
          <Zap size={18} color={flashOn ? "#FFC107" : "#fff"} />
        </button>
      </div>

      {/* Camera View */}
      <div className="flex-1 relative">
        <img
          src={SCAN_IMG}
          alt="Camera preview"
          className="w-full h-full object-cover"
          style={{ position: "absolute", inset: 0 }}
        />

        {/* Dark overlay */}
        <div className="absolute inset-0" style={{ background: "rgba(0,0,0,0.35)" }} />

        {/* Guide Frame */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div style={{ position: "relative", width: 260, height: 260 }}>
            {/* Corner brackets */}
            {[
              { top: 0, left: 0, borderTop: "3px solid #4CAF50", borderLeft: "3px solid #4CAF50" },
              { top: 0, right: 0, borderTop: "3px solid #4CAF50", borderRight: "3px solid #4CAF50" },
              { bottom: 0, left: 0, borderBottom: "3px solid #4CAF50", borderLeft: "3px solid #4CAF50" },
              { bottom: 0, right: 0, borderBottom: "3px solid #4CAF50", borderRight: "3px solid #4CAF50" },
            ].map((style, i) => (
              <div
                key={i}
                style={{
                  position: "absolute",
                  width: 36,
                  height: 36,
                  borderRadius: i < 2 ? (i === 0 ? "8px 0 0 0" : "0 8px 0 0") : (i === 2 ? "0 0 0 8px" : "0 0 8px 0"),
                  ...style,
                }}
              />
            ))}

            {/* Overlay text inside box */}
            {phase === "camera" && (
              <div
                className="absolute inset-0 flex items-center justify-center"
                style={{ background: "rgba(46,125,50,0.08)" }}
              >
                <div className="text-center p-4">
                  <div className="text-3xl mb-2">🌿</div>
                  <p style={{ color: "rgba(255,255,255,0.85)", fontSize: 13, fontWeight: 500 }}>
                    Align plant/pest in frame
                  </p>
                </div>
              </div>
            )}

            {/* Scan Line Animation */}
            {phase === "analyzing" && (
              <AnimatePresence>
                <motion.div
                  className="absolute left-0 right-0"
                  style={{
                    top: `${scanLineY}%`,
                    height: 2,
                    background: "linear-gradient(90deg, transparent, #4CAF50, #81C784, #4CAF50, transparent)",
                    boxShadow: "0 0 10px rgba(76,175,80,0.8)",
                  }}
                />
              </AnimatePresence>
            )}

            {/* Captured checkmark */}
            {phase === "captured" && (
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <CheckCircle2 size={48} color="#4CAF50" />
                </motion.div>
              </div>
            )}
          </div>
        </div>

        {/* Tips text */}
        {phase === "camera" && (
          <div className="absolute bottom-36 left-0 right-0 px-6">
            <div className="flex justify-center gap-4">
              {["📏 Get close to plant", "💡 Good lighting", "🎯 Center the pest"].map((tip) => (
                <div
                  key={tip}
                  className="px-3 py-1.5 rounded-full"
                  style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(8px)" }}
                >
                  <span style={{ color: "rgba(255,255,255,0.85)", fontSize: 11 }}>{tip}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Analyzing Progress */}
        {phase === "analyzing" && (
          <div className="absolute top-1/2 left-0 right-0 flex flex-col items-center" style={{ marginTop: 160 }}>
            <div className="rounded-2xl px-6 py-4 mx-8" style={{ background: "rgba(0,0,0,0.8)", backdropFilter: "blur(12px)" }}>
              <div className="flex items-center gap-3 mb-3">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                  className="rounded-full flex items-center justify-center"
                  style={{ width: 32, height: 32, background: "linear-gradient(135deg, #2E7D32, #66BB6A)" }}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M12 2C8 2 4 5 4 9c0 5 5 9 8 11 3-2 8-6 8-11 0-4-4-7-8-7z" fill="#fff" />
                  </svg>
                </motion.div>
                <div>
                  <p style={{ color: "#fff", fontWeight: 600, fontSize: 13 }}>AI Analyzing...</p>
                  <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 11 }}>Scanning for pests & diseases</p>
                </div>
              </div>

              <div className="rounded-full overflow-hidden mb-1" style={{ height: 6, background: "rgba(255,255,255,0.15)" }}>
                <motion.div
                  className="h-full rounded-full"
                  style={{
                    width: `${scanProgress}%`,
                    background: "linear-gradient(90deg, #2E7D32, #66BB6A)",
                    transition: "width 0.2s ease",
                  }}
                />
              </div>
              <div className="flex justify-between">
                <span style={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }}>Processing image...</span>
                <span style={{ color: "#66BB6A", fontSize: 11, fontWeight: 600 }}>{Math.round(scanProgress)}%</span>
              </div>

              <div className="mt-3 flex flex-col gap-1">
                {["✅ Image captured", `${scanProgress > 40 ? "✅" : "⏳"} Running pest detection AI`, `${scanProgress > 75 ? "✅" : "⏳"} Identifying crop disease`].map((step) => (
                  <p key={step} style={{ color: "rgba(255,255,255,0.7)", fontSize: 11 }}>{step}</p>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Controls */}
      {phase !== "analyzing" && (
        <div
          className="relative z-20 px-6 py-6"
          style={{ background: "linear-gradient(to top, rgba(0,0,0,0.9), transparent)" }}
        >
          {phase === "camera" && (
            <>
              <div className="flex items-center justify-between mb-6">
                <button
                  onClick={() => navigate("/pest-results")}
                  className="flex flex-col items-center gap-1.5"
                >
                  <div
                    className="flex items-center justify-center rounded-2xl"
                    style={{ width: 54, height: 54, background: "rgba(255,255,255,0.15)", backdropFilter: "blur(10px)", border: "1.5px solid rgba(255,255,255,0.2)" }}
                  >
                    <Image size={24} color="#fff" />
                  </div>
                  <span style={{ color: "rgba(255,255,255,0.7)", fontSize: 11 }}>Gallery</span>
                </button>

                {/* Main Capture Button */}
                <motion.button
                  whileTap={{ scale: 0.92 }}
                  onClick={handleCapture}
                  className="flex items-center justify-center rounded-full"
                  style={{
                    width: 78,
                    height: 78,
                    background: "rgba(255,255,255,0.15)",
                    backdropFilter: "blur(10px)",
                    border: "4px solid #fff",
                    boxShadow: "0 0 0 2px rgba(255,255,255,0.3), 0 8px 24px rgba(0,0,0,0.4)",
                  }}
                >
                  <div className="rounded-full" style={{ width: 60, height: 60, background: "#fff" }} />
                </motion.button>

                <button className="flex flex-col items-center gap-1.5">
                  <div
                    className="flex items-center justify-center rounded-2xl"
                    style={{ width: 54, height: 54, background: "rgba(255,255,255,0.15)", backdropFilter: "blur(10px)", border: "1.5px solid rgba(255,255,255,0.2)" }}
                  >
                    <FlipHorizontal size={24} color="#fff" />
                  </div>
                  <span style={{ color: "rgba(255,255,255,0.7)", fontSize: 11 }}>Flip</span>
                </button>
              </div>

              <p style={{ textAlign: "center", color: "rgba(255,255,255,0.5)", fontSize: 12 }}>
                Tap to capture · Works best in daylight
              </p>
            </>
          )}

          {phase === "captured" && (
            <div className="flex gap-3">
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => setPhase("camera")}
                className="flex-1 py-4 rounded-2xl flex items-center justify-center gap-2"
                style={{
                  background: "rgba(255,255,255,0.12)",
                  border: "1.5px solid rgba(255,255,255,0.25)",
                  color: "#fff",
                  fontSize: 15,
                  fontWeight: 600,
                }}
              >
                <X size={18} /> Retake
              </motion.button>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={handleAnalyze}
                className="flex-1 py-4 rounded-2xl flex items-center justify-center gap-2"
                style={{
                  background: "linear-gradient(135deg, #2E7D32, #66BB6A)",
                  color: "#fff",
                  fontSize: 15,
                  fontWeight: 700,
                  boxShadow: "0 6px 20px rgba(46,125,50,0.4)",
                }}
              >
                <Zap size={18} /> Analyze with AI
              </motion.button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
