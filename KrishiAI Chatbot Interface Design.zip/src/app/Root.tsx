import { Outlet } from "react-router";

export function Root() {
  return (
    <div className="min-h-screen" style={{ fontFamily: "'Inter', sans-serif", background: "#F8FAF9" }}>
      <Outlet />
    </div>
  );
}
