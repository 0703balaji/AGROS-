import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useNavigate } from "react-router";
import {
  User, MapPin, ShoppingBag, Users, BookOpen, Bookmark,
  Settings, Bell, LogOut, ChevronRight, Leaf, TrendingUp,
  Award, CreditCard
} from "lucide-react";

const MENU_SECTIONS = [
  {
    title: "Account",
    items: [
      { icon: User, label: "Profile Settings", path: "/profile", desc: "Manage your account" },
      { icon: MapPin, label: "My Fields", path: "/fields", desc: "3 fields registered" },
      { icon: Award, label: "Achievements", path: "/achievements", desc: "View your progress" },
    ]
  },
  {
    title: "Marketplace",
    items: [
      { icon: ShoppingBag, label: "My Listings", path: "/listings", desc: "Active products" },
      { icon: CreditCard, label: "Transactions", path: "/transactions", desc: "Sales history" },
      { icon: TrendingUp, label: "Analytics", path: "/analytics", desc: "Performance metrics" },
    ]
  },
  {
    title: "Community",
    items: [
      { icon: Users, label: "My Posts", path: "/community", desc: "Forum activity" },
      { icon: BookOpen, label: "Learning Courses", path: "/knowledge", desc: "Continue learning" },
      { icon: Bookmark, label: "Saved Content", path: "/saved", desc: "Bookmarked items" },
    ]
  },
  {
    title: "System",
    items: [
      { icon: Bell, label: "Notifications", path: "/notifications", desc: "3 unread" },
      { icon: Settings, label: "Settings", path: "/settings", desc: "App preferences" },
    ]
  }
];

export function ProfileMenu() {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const userName = "Ravi Kumar";
  const userDistrict = "Thanjavur";

  const handleNavigation = (path: string) => {
    navigate(path);
    setIsOpen(false);
  };

  return (
    <>
      {/* Profile Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-center rounded-xl"
        style={{ width: 34, height: 34, background: "rgba(255,255,255,0.15)" }}
      >
        <User size={16} color="#fff" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 z-40"
              style={{ background: "rgba(0, 0, 0, 0.15)", backdropFilter: "blur(2px)" }}
            />

            {/* Menu Panel */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="fixed right-4 top-16 z-50 w-[90vw] max-w-[420px]"
              style={{
                background: "#ffffff",
                borderRadius: "20px",
                boxShadow: "0 20px 60px rgba(0, 0, 0, 0.12), 0 0 1px rgba(0, 0, 0, 0.1)",
                overflow: "hidden",
              }}
            >
              {/* User Header */}
              <div
                className="p-5 border-b"
                style={{
                  background: "linear-gradient(135deg, #2E7D32 0%, #1B5E20 100%)",
                  borderBottom: "1px solid rgba(255, 255, 255, 0.1)",
                }}
              >
                <div className="flex items-center gap-3">
                  <div
                    className="rounded-full flex items-center justify-center"
                    style={{
                      width: 50,
                      height: 50,
                      background: "rgba(255, 255, 255, 0.2)",
                      border: "2px solid rgba(255, 255, 255, 0.3)",
                    }}
                  >
                    <User size={24} color="#fff" />
                  </div>
                  <div>
                    <p style={{ fontFamily: "'Poppins', sans-serif", fontWeight: 700, fontSize: 17, color: "#fff" }}>
                      {userName}
                    </p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <MapPin size={12} color="rgba(255, 255, 255, 0.7)" />
                      <p style={{ fontSize: 13, color: "rgba(255, 255, 255, 0.8)" }}>{userDistrict}, Tamil Nadu</p>
                    </div>
                  </div>
                </div>
                
                {/* Quick Stats */}
                <div className="grid grid-cols-3 gap-3 mt-4">
                  {[
                    { label: "Fields", value: "3", icon: MapPin },
                    { label: "Posts", value: "12", icon: Users },
                    { label: "Courses", value: "5", icon: BookOpen },
                  ].map((stat) => (
                    <div
                      key={stat.label}
                      className="rounded-xl p-2.5 text-center"
                      style={{ background: "rgba(255, 255, 255, 0.15)", backdropFilter: "blur(10px)" }}
                    >
                      <stat.icon size={14} color="#fff" className="mx-auto mb-1" />
                      <p style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>{stat.value}</p>
                      <p style={{ fontSize: 10, color: "rgba(255, 255, 255, 0.7)" }}>{stat.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Menu Sections */}
              <div className="max-h-[60vh] overflow-y-auto" style={{ scrollbarWidth: "none" }}>
                {MENU_SECTIONS.map((section, sectionIdx) => (
                  <div key={section.title} className={sectionIdx > 0 ? "border-t" : ""} style={{ borderColor: "#F0F0F0" }}>
                    <p
                      className="px-5 pt-4 pb-2"
                      style={{ fontSize: 11, fontWeight: 700, color: "#999", letterSpacing: "0.5px", textTransform: "uppercase" }}
                    >
                      {section.title}
                    </p>
                    {section.items.map((item) => (
                      <motion.button
                        key={item.label}
                        onClick={() => handleNavigation(item.path)}
                        onMouseEnter={() => setHoveredItem(item.label)}
                        onMouseLeave={() => setHoveredItem(null)}
                        whileTap={{ scale: 0.98 }}
                        className="w-full flex items-center gap-3 px-5 py-3 transition-colors"
                        style={{
                          background: hoveredItem === item.label ? "#F8FAF9" : "transparent",
                        }}
                      >
                        <div
                          className="rounded-xl flex items-center justify-center flex-shrink-0"
                          style={{
                            width: 36,
                            height: 36,
                            background: hoveredItem === item.label ? "#E8F5E9" : "#F5F5F5",
                            transition: "all 0.2s ease",
                          }}
                        >
                          <item.icon size={18} color={hoveredItem === item.label ? "#2E7D32" : "#666"} />
                        </div>
                        <div className="flex-1 text-left">
                          <p style={{ fontSize: 14, fontWeight: 600, color: "#1a1a1a" }}>{item.label}</p>
                          <p style={{ fontSize: 12, color: "#888" }}>{item.desc}</p>
                        </div>
                        <ChevronRight
                          size={16}
                          color="#ccc"
                          style={{ opacity: hoveredItem === item.label ? 1 : 0, transition: "opacity 0.2s" }}
                        />
                      </motion.button>
                    ))}
                  </div>
                ))}
              </div>

              {/* Logout Button */}
              <div className="border-t p-4" style={{ borderColor: "#F0F0F0", background: "#FAFAFA" }}>
                <motion.button
                  whileTap={{ scale: 0.97 }}
                  onClick={() => {
                    setIsOpen(false);
                    navigate("/");
                  }}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl"
                  style={{
                    background: "#fff",
                    border: "1.5px solid #E0E0E0",
                    fontWeight: 600,
                    fontSize: 14,
                    color: "#C62828",
                  }}
                >
                  <LogOut size={16} />
                  Sign Out
                </motion.button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}